import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';

// Firebase imports
import { AngularFireModule } from '@angular/fire/compat';
import { AngularFireAuthModule } from '@angular/fire/compat/auth';

const firebaseConfig = {
  apiKey: "AIzaSyC8ShElKOLoVt8mNm8BtGd1jUl6qHdjxWU",
  authDomain: "tricy-track-ebc7c.firebaseapp.com",
  projectId: "tricy-track-ebc7c",
  storageBucket: "tricy-track-ebc7c.appspot.com", // <-- fix here
  messagingSenderId: "32815437782",
  appId: "1:32815437782:web:5f63f7500bbd36108fb677",
  measurementId: "G-BRGSL08T7S"
};


@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    HttpClientModule,
    IonicModule.forRoot(),
    AppRoutingModule,
    AngularFireModule.initializeApp(firebaseConfig),
    AngularFireAuthModule,
  ],
  providers: [{ provide: RouteReuseStrategy, useClass: IonicRouteStrategy }],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]  // <-- Add this if still errors persist
})
export class AppModule {}

