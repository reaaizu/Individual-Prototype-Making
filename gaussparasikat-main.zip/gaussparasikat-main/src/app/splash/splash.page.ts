import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-splash',
  templateUrl: './splash.page.html',
  styleUrls: ['./splash.page.scss'],
  standalone: true,
  imports: [IonicModule] // ✅ Ensures Ionic components work
})
export class SplashPage {
  constructor(private router: Router) {}

  ngOnInit() {
    this.checkAppReadiness();
  }

  async checkAppReadiness() {
    // Simulate an actual app readiness check (e.g., waiting for APIs, DB connections, etc.)
    await this.waitForAppToLoad();
    
    // Redirect to the FolderPage after loading is complete
    this.router.navigateByUrl('/folder/Home');
  }

  waitForAppToLoad(): Promise<void> {
    return new Promise((resolve) => {
      const interval = setInterval(() => {
        const appLoaded = this.isAppReady();
        if (appLoaded) {
          clearInterval(interval);
          resolve();
        }
      }, 500); // Check every 500ms
    });
  }

  isAppReady(): boolean {
    // Replace this with real checks (e.g., API data loaded, storage initialized)
    return true; // Set to true when the app is actually ready
  }
}
