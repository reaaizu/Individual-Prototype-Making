import { Component, OnInit } from '@angular/core';
import { Platform, MenuController } from '@ionic/angular';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';

import { App } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
  standalone: false
})
export class AppComponent implements OnInit {

  public appPages = [
    { title: 'Home', url: '/folder/Home', icon: 'bird' },
    { title: 'History', url: '/folder/History', icon: 'paper-plane' },
    { title: 'List of TODAs', url: '/folder/List of Todas', icon: 'heart' },
    { title: 'Suggestions', url: '/folder/Suggestions', icon: 'archive' },
    { title: 'Settings', url: '/folder/Settings', icon: 'trash' },
    { title: 'Profile', url: '/profile', icon: 'person-circle' }
  ];

  public email: string | null = null;
  public profileImageUrl: string | null = null;

  constructor(
    private platform: Platform,
    private router: Router,
    private menuCtrl: MenuController
  ) {
    this.initializeApp();
  }

  ngOnInit(): void {
    this.loadUserData();

    window.addEventListener('userAuthChanged', () => {
      this.loadUserData();
      this.updateSwipeGesture();
    });

    this.router.events
      .pipe(filter(e => e instanceof NavigationEnd))
      .subscribe(() => this.updateSwipeGesture());
  }

  private clearLocalUserData(): void {
    localStorage.removeItem('userEmail');
    localStorage.removeItem('user_email');
    localStorage.removeItem('userPassword');
    localStorage.removeItem('userData');
    localStorage.removeItem('userProfileImageUrl');
    localStorage.removeItem('authCodeSaved');
    localStorage.removeItem('isGoogleUser');
  }

  private forceLogoutAndGoLogin(): void {
    this.clearLocalUserData();
    window.dispatchEvent(new Event('userAuthChanged'));

    this.menuCtrl.close();
    this.menuCtrl.swipeGesture(false);

    // prevent repeat navigation spam
    if (!this.router.url.startsWith('/login')) {
      this.router.navigate(['/login']);
    }
  }

  initializeApp(): void {
    this.platform.ready().then(() => {

      // ✅ 1) logout every fresh app start
      this.forceLogoutAndGoLogin();

      // ✅ 2) logout when coming back from background (Android/iOS only)
      if (Capacitor.isNativePlatform()) {
        App.addListener('appStateChange', ({ isActive }) => {
          if (isActive) {
            this.forceLogoutAndGoLogin();
          }
        });
      }

      this.updateSwipeGesture();
    });
  }

  loadUserData(): void {
    this.email = localStorage.getItem('userEmail');
    this.profileImageUrl = localStorage.getItem('userProfileImageUrl');
  }

  updateSwipeGesture(): void {
    const loggedIn = !!localStorage.getItem('userEmail');
    const currentUrl = this.router.url;

    if (loggedIn && !currentUrl.startsWith('/signup') && !currentUrl.startsWith('/login')) {
      this.menuCtrl.swipeGesture(true);
    } else {
      this.menuCtrl.swipeGesture(false);
    }
  }

  goToProfile(): void {
    this.router.navigate(['/profile']);
    this.menuCtrl.close();
  }
}