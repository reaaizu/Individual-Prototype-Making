import { Component } from '@angular/core';
import { IonicModule, NavController, MenuController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import 'firebase/compat/auth';

import { Capacitor } from '@capacitor/core';
import { FirebaseAuthentication } from '@capacitor-firebase/authentication';
// Firebase and AngularFire for Google auth
import { AngularFireAuth } from '@angular/fire/compat/auth';
import firebase from 'firebase/compat/app';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule],
})
export class LoginPage {
  emailOrPhone = '';
  password = '';
  passwordType = 'password';
  isLoading = false;

  // ✅ FIX: Ensure these URLs match your server folder structure
  private readonly API_URL = 'https://qid.duv.temporary.site/login-api/login.php';
  private readonly PROFILE_URL = 'https://qid.duv.temporary.site/profile-api/getProfile.php';

  constructor(
    private navCtrl: NavController,
    private http: HttpClient,
    private menuCtrl: MenuController,
    private router: Router,
    private afAuth: AngularFireAuth
  ) {}

  ionViewWillEnter(): void {
    this.menuCtrl.swipeGesture(false);
    this.menuCtrl.enable(false);
  }

  ionViewWillLeave(): void {
    this.menuCtrl.enable(true);
  }

  togglePassword(): void {
    this.passwordType = this.passwordType === 'password' ? 'text' : 'password';
  }

  goToSignup(): void {
    this.navCtrl.navigateRoot('/signup');
  }

  // --------------------------------------------------
  // ✅ IDENTIFIER HELPERS
  // --------------------------------------------------

  private isEmail(value: string): boolean {
    const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return pattern.test(value);
  }

  private stripToDigits(raw: string): string {
    return raw.trim().replace(/\D/g, ''); // Keep only digits
  }

  /**
   * ✅ FIX: Database shows numbers like 09565628936 (11 digits).
   * This formatter ensures the input matches the DB format.
   */
  private autoFormatPhone(raw: string): string {
    let v = this.stripToDigits(raw);

    // If starts with 63, convert to 0 (639... -> 09...)
    if (v.startsWith('63') && v.length >= 12) {
      return '0' + v.substring(2);
    }
    // If starts with 9, add 0 (9... -> 09...)
    if (v.startsWith('9') && v.length === 10) {
      return '0' + v;
    }
    return v;
  }

  private getIdentifier(): { identifier: string; kind: 'email' | 'phone' } | null {
    const raw = this.emailOrPhone.trim();
    if (!raw) return null;

    if (this.isEmail(raw)) {
      return { identifier: raw, kind: 'email' };
    }

    const formattedPhone = this.autoFormatPhone(raw);
    // Standard PH number is 11 digits starting with 09
    if (/^09\d{9}$/.test(formattedPhone)) {
      return { identifier: formattedPhone, kind: 'phone' };
    }

    return null;
  }

  // --------------------------------------------------
  // ✅ AUTH HELPERS
  // --------------------------------------------------

  private saveSession(identifier: string): void {
    localStorage.setItem('userEmail', identifier);
    localStorage.setItem('user_email', identifier);
    window.dispatchEvent(new Event('userAuthChanged'));
  }

  private fetchProfileExtras(identifier: string): void {
    this.http.post<any>(this.PROFILE_URL, { email: identifier }).subscribe({
      next: (profileRes) => {
        if (profileRes?.profile_picture) {
          const finalUrl = `${profileRes.profile_picture.replace(/[?&]t=\d+/, '')}?t=${Date.now()}`;
          localStorage.setItem('userProfileImageUrl', finalUrl);
          window.dispatchEvent(new Event('userProfileUpdated'));
        }
        if (profileRes?.authCode) localStorage.setItem('authCodeSaved', 'true');
        if (profileRes?.isGoogleUser) localStorage.setItem('isGoogleUser', 'true');
      },
      error: (err) => console.warn('Profile sync failed:', err)
    });
  }

  private afterAuthSuccess(identifier: string): void {
    this.saveSession(identifier);
    this.navCtrl.navigateRoot('/folder/Home');
  }

  // --------------------------------------------------
  // ✅ LOGIN ACTIONS
  // --------------------------------------------------

  login(): void {
    const id = this.getIdentifier();
    const pass = this.password.trim();

    if (!id || !pass) {
      alert('Please enter a valid email/phone and password.');
      return;
    }

    // Reflect formatted phone in UI if necessary
    if (id.kind === 'phone') this.emailOrPhone = id.identifier;

    this.isLoading = true;
    const payload = { email: id.identifier, password: pass };

    this.http.post<any>(this.API_URL, payload).subscribe({
      next: (res) => {
        this.isLoading = false;
        if (res?.status === 'success') {
          if (res?.authCodeExists) localStorage.setItem('authCodeSaved', 'true');
          this.fetchProfileExtras(id.identifier);
          this.afterAuthSuccess(id.identifier);
        } else {
          alert(res?.message || 'Login failed.');
        }
      },
      error: (err) => {
        this.isLoading = false;
        console.error('API Error:', err);
        // Alert if it's a 404 to help debugging
        const msg = err.status === 404 ? 'API file not found (404).' : 'Server connection error.';
        alert(msg);
      }
    });
  }

  async signInWithGoogle(): Promise<void> {
  this.isLoading = true;

  try {
    let email: string | null = null;
    let displayName: string | null = null;
    let uid: string | null = null;

    if (Capacitor.isNativePlatform()) {
      // ✅ Android / iOS (native)
      const result = await FirebaseAuthentication.signInWithGoogle();
      email = result.user?.email ?? null;
      displayName = result.user?.displayName ?? null;
      uid = result.user?.uid ?? null;
    } else {
      // ✅ Web (popup)
      const provider = new firebase.auth.GoogleAuthProvider();
      const result = await this.afAuth.signInWithPopup(provider);
      email = result.user?.email ?? null;
      displayName = result.user?.displayName ?? null;
      uid = result.user?.uid ?? null;
    }

    if (!email || !uid) {
      alert('Failed to get Google account info.');
      return;
    }

    // ✅ IMPORTANT: mode='login' so backend will ONLY check DB, not create user
    const payload = {
      email,
      displayName,
      uid,
      googleSignIn: true,
      mode: 'login',
    };

    this.http.post<any>(this.API_URL, payload).subscribe({
      next: (res) => {
        if (res?.status === 'success') {
          this.fetchProfileExtras(email!);
          this.afterAuthSuccess(email!);
        } else {
          alert(res?.message || 'Google login failed.');
        }
      },
      error: (err) => {
        // If backend returns 404 -> not registered yet
        if (err?.status === 404) {
          alert('No account found for this Google email. Please sign up first.');
          // optional: bring them to signup page
          this.navCtrl.navigateRoot('/signup');
        } else {
          console.error(err);
          alert('Could not connect to backend for Google login.');
        }
      },
      complete: () => (this.isLoading = false),
    });

  } catch (error: any) {
    console.error('Google Sign-In failed:', error);
    const msg =
      error?.code === 'auth/unauthorized-domain'
        ? 'This domain is not authorized in Firebase Console.'
        : error?.message || 'Google Sign-In failed.';
    alert(msg);
    this.isLoading = false;
  }
}
}