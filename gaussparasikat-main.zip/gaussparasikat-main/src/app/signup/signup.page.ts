import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NavController, IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

// Firebase (web)
import { AngularFireAuth } from '@angular/fire/compat/auth';
import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';

// Capacitor (mobile)
import { Capacitor } from '@capacitor/core';
import { FirebaseAuthentication } from '@capacitor-firebase/authentication';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.page.html',
  styleUrls: ['./signup.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule],
})
export class SignupPage {
  emailOrPhone = '';
  password = '';
  confirmPassword = '';

  showPassword = false;
  showConfirmPassword = false;

  isLoading = false;

  private API_URL = 'https://qid.duv.temporary.site/signup-api/signup.php';
  private SEND_VERIFICATION_URL = 'https://qid.duv.temporary.site/signup-api/send-verification.php';

  constructor(
    private navCtrl: NavController,
    private http: HttpClient,
    private afAuth: AngularFireAuth
  ) {}

  goToLogin(): void {
    this.navCtrl.navigateRoot('/login');
  }

  private saveSession(identifier: string): void {
    localStorage.setItem('userEmail', identifier);
    window.dispatchEvent(new Event('userAuthChanged'));
  }

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  toggleConfirmPasswordVisibility() {
    this.showConfirmPassword = !this.showConfirmPassword;
  }

  isEmail(value: string): boolean {
    const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return pattern.test(value);
  }

  normalizePhone(phone: string): string {
    return phone.replace(/[^\d+]/g, '');
  }

  isPhone(value: string): boolean {
    const phone = this.normalizePhone(value);
    return /^\+?\d{10,15}$/.test(phone);
  }

  getIdentifier(): string | null {
    const raw = this.emailOrPhone.trim();
    if (this.isEmail(raw)) return raw;

    const phone = this.normalizePhone(raw);
    if (this.isPhone(phone)) return phone;

    return null;
  }

  async signInWithGoogle() {
    this.isLoading = true;

    try {
      let email: string | null = null;
      let displayName: string | null = null;
      let uid: string | null = null;

      if (Capacitor.isNativePlatform()) {
        const result = await FirebaseAuthentication.signInWithGoogle();
        email = result.user?.email ?? null;
        displayName = result.user?.displayName ?? null;
        uid = result.user?.uid ?? null;
      } else {
        const provider = new firebase.auth.GoogleAuthProvider();
        const result = await this.afAuth.signInWithPopup(provider);
        email = result.user?.email ?? null;
        displayName = result.user?.displayName ?? null;
        uid = result.user?.uid ?? null;
      }

      if (!email || !uid) {
        alert('Failed to get Google account info.');
        this.isLoading = false;
        return;
      }

      const payload = {
        email,
        displayName,
        uid,
        googleSignIn: true,
        mode: 'signup',
      };

      this.http.post(this.API_URL, payload).subscribe({
        next: (res: any) => {
          if (res.status === 'success') {
            this.saveSession(email!);
            this.navCtrl.navigateRoot('/login');
          } else {
            alert('Signup failed: ' + res.message);
          }
        },
        error: (err) => {
          console.error(err);
          alert('Server connection error.');
        },
        complete: () => (this.isLoading = false),
      });
    } catch (error: any) {
      console.error(error);
      alert('Google Sign-In failed: ' + (error?.message ?? 'Unknown error'));
      this.isLoading = false;
    }
  }

  signUp() {
    const identifier = this.getIdentifier();

    this.password = this.password.trim();
    this.confirmPassword = this.confirmPassword.trim();

    if (!this.emailOrPhone || !this.password || !this.confirmPassword) {
      alert('Please fill in all fields.');
      return;
    }

    if (!identifier) {
      alert('Enter a valid email or phone number.');
      return;
    }

    if (this.password !== this.confirmPassword) {
      alert('Passwords do not match.');
      return;
    }

    const payload = {
      email: identifier,
      password: this.password,
    };

    this.isLoading = true;

    this.http.post(this.API_URL, payload).subscribe({
      next: (res: any) => {
        if (res.status !== 'success') {
          alert('Signup failed: ' + res.message);
          return;
        }

        // Email signup: send verification then go to verify page
        if (res.requiresVerification && this.isEmail(identifier)) {
          this.http.post(this.SEND_VERIFICATION_URL, { email: identifier }).subscribe({
            next: (verifyRes: any) => {
              if (verifyRes.status === 'success') {
                localStorage.setItem('pendingVerificationEmail', identifier);
                this.navCtrl.navigateForward('/verify-email');
              } else {
                alert('Signup succeeded, but sending verification failed: ' + verifyRes.message);
              }
            },
            error: (err) => {
              console.error(err);
              alert('Signup succeeded, but verification email could not be sent.');
            },
            complete: () => (this.isLoading = false),
          });
          return;
        }

        // Phone signup or non-email flow
        this.saveSession(identifier);
        this.navCtrl.navigateRoot('/login');
      },
      error: (err) => {
        console.error(err);
        alert('Server error. Please try again.');
      },
      complete: () => {
        // handled inside nested request for email flow
      },
    });
  }
}