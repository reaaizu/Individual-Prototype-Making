import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PrivacyPage } from './privacy.page';

const routes: Routes = [
  {
    path: '',
    component: PrivacyPage, // ✅ Use it here instead of declarations
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes), PrivacyPage], // ✅ Import PrivacyPage directly
})
export class PrivacyPageModule {}
