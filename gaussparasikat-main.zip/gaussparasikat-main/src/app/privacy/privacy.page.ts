import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-privacy',
  templateUrl: './privacy.page.html',
  styleUrls: ['./privacy.page.scss'],
  standalone: true, // ✅ Ensure this is standalone
  imports: [CommonModule, IonicModule], // ✅ Import IonicModule
})
export class PrivacyPage {}
