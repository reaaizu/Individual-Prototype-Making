import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { LoginPage } from './login/login.page';
import { HowPage } from './how/how.page';
import { AuthGuard } from './guards/auth.guard'; // 🔐 Import the guard

const routes: Routes = [
  {
    path: '',
    redirectTo: 'signup',
    pathMatch: 'full'
  },
  {
    path: 'signup',
    loadChildren: () => import('./signup/signup.module').then(m => m.SignupPageModule)
  },
  {
    path: 'login',
    component: LoginPage
  },
  {
    path: 'folder/:id',
    loadChildren: () => import('./folder/folder.module').then(m => m.FolderPageModule),
    canActivate: [AuthGuard] // 🔐 Protected route
  },
  {
    path: 'profile',
    loadChildren: () => import('./profile/profile.module').then(m => m.ProfilePageModule),
    canActivate: [AuthGuard] // 🔐 Protected route
  },
  {
    path: 'app',
    component: AppComponent
  },
  {
    path: 'howtouse',
    component: HowPage
  },
  {
    path: 'how',
    loadChildren: () => import('./how/how.module').then(m => m.HowPage)
  },
  {
    path: 'tac',
    loadChildren: () => import('./tac/tac.module').then(m => m.TacPageModule)
  },
  {
    path: 'privacy',
    loadChildren: () => import('./privacy/privacy.module').then(m => m.PrivacyPageModule)
  },
  {
    path: 'splash',
    loadChildren: () => import('./splash/splash.module').then(m => m.SplashPageModule),
    canActivate: [AuthGuard] // Optional: protect splash if needed
  },
  {
  path: 'verify-email',
  loadComponent: () =>
    import('./verify/verify-email.page').then(m => m.VerifyEmailPage)
}
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
