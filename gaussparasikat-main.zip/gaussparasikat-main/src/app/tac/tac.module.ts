import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TacPage } from './tac.page'; // ✅ Import standalone component

const routes: Routes = [
  { path: '', component: TacPage }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes), 
    TacPage // ✅ Import standalone component here
  ],
})
export class TacPageModule { }
