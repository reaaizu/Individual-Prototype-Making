import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TacPage } from './tac.page';

const routes: Routes = [
  {
    path: '',
    component: TacPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TacPageRoutingModule {}
