import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TacPage } from './tac.page';

describe('TacPage', () => {
  let component: TacPage;
  let fixture: ComponentFixture<TacPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(TacPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
