import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NavController, IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-verify-email',
  templateUrl: './verify-email.page.html',
  styleUrls: ['./verify-email.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule],
})
export class VerifyEmailPage {
  code = '';
  email = localStorage.getItem('pendingVerificationEmail') || '';
  isLoading = false;

  private VERIFY_URL = 'https://qid.duv.temporary.site/signup-api/verify-email.php';
  private RESEND_URL = 'https://qid.duv.temporary.site/signup-api/send-verification.php';

  constructor(
    private http: HttpClient,
    private navCtrl: NavController
  ) {}

  verifyEmail() {
    if (!this.email || !this.code.trim()) {
      alert('Enter the verification code.');
      return;
    }

    this.isLoading = true;

    this.http.post(this.VERIFY_URL, {
      email: this.email,
      code: this.code.trim()
    }).subscribe({
      next: (res: any) => {
        if (res.status === 'success') {
          localStorage.removeItem('pendingVerificationEmail');
          alert('Email verified successfully.');
          this.navCtrl.navigateRoot('/login');
        } else {
          alert(res.message);
        }
      },
      error: (err) => {
        console.error(err);
        alert('Verification failed.');
      },
      complete: () => (this.isLoading = false),
    });
  }

  resendCode() {
    if (!this.email) {
      alert('No email found.');
      return;
    }

    this.isLoading = true;

    this.http.post(this.RESEND_URL, { email: this.email }).subscribe({
      next: (res: any) => {
        alert(res.message);
      },
      error: (err) => {
        console.error(err);
        alert('Failed to resend code.');
      },
      complete: () => (this.isLoading = false),
    });
  }
}