import { Component, inject, OnInit, ViewChild, AfterViewInit, OnDestroy, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NavController, IonModal } from '@ionic/angular';
import { OverlayEventDetail } from '@ionic/core/components';
import { Subject } from 'rxjs';
import { ChangeDetectorRef } from '@angular/core';
import { Platform } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { ToastController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';


// REPLACE the terminalIcons object (lines 13-120) with this:

const terminalIcons: { [key: string]: string } = {
  'DEUNITODA(Sta. Lucia)': 'assets/icon/DEUNITODA.png',
  'DEUNITODA(Southville)': 'assets/icon/DEUNITODA.png',
  'DEUNITODA(48 Mariano)': 'assets/icon/DEUNITODA.png',
  'DOCTODA(Octagon)': 'assets/icon/DOCTODA.png',
  'DOCTODA(ADR)': 'assets/icon/DOCTODA.png',
  'VAMTODA(Alfonso)': 'assets/icon/VAMTODA.png',
  'FHNAPICOTODA(Lifehomes)': 'assets/icon/FHNAPICOTODA.png',
  'MPGVTODA(Gate 1)': 'assets/icon/MPGVTODA.png',
  'MPGVTODA(Hawaii)': 'assets/icon/MPGVTODA.png',
  'MAMTODA(Mabini)': 'assets/icon/MAMTODA.png',
  'MAMTODA(Feliciano)': 'assets/icon/MAMTODA.png',
  'MLKPPTODA(Magsaysay)': 'assets/icon/MLKPPTODA.png',
  'MLKPPTODA(K Center)': 'assets/icon/MLKPPTODA.png',
  'PROFMATODA(Rainforest)': 'assets/icon/PROFMATODA.png',
  'PROFMATODA(Palengke)': 'assets/icon/PROFMATODA.png',
  'PROFMATODA(Legaspi)': 'assets/icon/PROFMATODA.png',
  'PROFMATODA(Eusebio)': 'assets/icon/PROFMATODA.png',
  'PROFMATODA(Stella Maris)': 'assets/icon/PROFMATODA.png',
  'PRRESJMTODA(PCGH)': 'assets/icon/PRESSJMTODA.png',
  'PRRESJMTODA(Rose St)': 'assets/icon/PRESSJMTODA.png',
  'PRRESJMTODA(Eusebio)': 'assets/icon/PRESSJMTODA.png',
  'PSSSRMTODA(Tulay)': 'assets/icon/PSSSRMTODA.png',
  'PSSSRMTODA(MI SG)': 'assets/icon/PSSSRMTODA.png',
  'SANSETODA(Urbano)': 'assets/icon/SANSETODA.png',
  'SANSETODA(Palengke)': 'assets/icon/SANSETODA.png',
  'JABSONTODA(Velasco)': 'assets/icon/JABSONTODA.png',
  'BESCPPTODA(Esguerra)': 'assets/icon/BESCPPTODA.png',
  'NAGTODA(Sunrise)': 'assets/icon/NAGTODA.png',
  'NAGTODA(Novo)': 'assets/icon/NAGTODA.png',
  'NAGTODA(Eusebio)': 'assets/icon/NAGTODA.png',
  'RAMTODA(Palengke)': 'assets/icon/RAMTODA.png',
  'RAMTODA(Heroes)': 'assets/icon/RAMTODA.png',
  'SPRGEVTODA(Central)': 'assets/icon/SPRGEVTODA.png',
  'SLRPPTODA(Central)': 'assets/icon/SLRPPTODA.png',
  'SLRPPTODA(Taytay)': 'assets/icon/SLRPPTODA.png',
  'PPCTODA(Central)': 'assets/icon/PPCTODA.png',
  'PPCTODA(Urbano)': 'assets/icon/PPCTODA.png',
  'PPCTODA(Centennial)': 'assets/icon/PPCTODA.png',
  'PPCTODA(Bamboo)': 'assets/icon/PPCTODA.png',
  'MIPTODA(Palengke)': 'assets/icon/MIPTODA.png',
  'MIPTODA(Sandoval)': 'assets/icon/MIPTODA.png',
  'MIPTODA(Ilugin)': 'assets/icon/MIPTODA.png',
  'PPEATODA(Palengke)': 'assets/icon/PPEAATODA.png',
  'PPEATODA(Eusebio)': 'assets/icon/PPEAATODA.png',
  'ATODA(Palengke)': 'assets/icon/ATODA.png',
  'ATODA(Acacia)': 'assets/icon/ATODA.png',
  'PPFHTODA(Palengke)': 'assets/icon/PPFHTODA.png',
  'PPFHTODA(FishPort)': 'assets/icon/PPFHTODA.png',
  'EAPPPTODA(Palengke)': 'assets/icon/EAPPTODA.png',
  'EAPPPTODA(Super8)': 'assets/icon/EAPPTODA.png',
  'JRFMTODA(Rosario)': 'assets/icon/JRFMTODA.png',
  'JRFMTODA(Jennys)': 'assets/icon/JRFMTODA.png',
  'FEMPATTODA(Ortigas)': 'assets/icon/FEMPATTODA.png',
  'PRTMGTODA(Greenland)': 'assets/icon/PRTMGTODA.png',
  'PRTMGTODA(Raymundo)': 'assets/icon/PRTMGTODA.png',
  'PRTMGTODA(Sixto)': 'assets/icon/PRTMGTODA.png',
  'PRTMGTODA(Pasco)': 'assets/icon/PRTMGTODA.png',
  'PRTMGTODA(Quezon)': 'assets/icon/PRTMGTODA.png',
  'BRFMTODA(Ortigas)': 'assets/icon/BRMFTODA.png',
  'BRFMTODA(E Bank)': 'assets/icon/BRMFTODA.png',
  'TAPCJRTODA(EAR)': 'assets/icon/TAPCGRTODA.png',
  'TAPCJRTODA(Jabson)': 'assets/icon/TAPCGRTODA.png',
  'RSGSPSTODA(Paseo)': 'assets/icon/RSGSPSTODA.png',
  'RVTODA(Riverside)': 'assets/icon/RVTODA.png',
  'SMEOTODAPC(SM East)': 'assets/icon/SMEOTODAPC.png',
  'SLMTODA(Mabuhay)': 'assets/icon/SLMTODA.png',
  'SLMTODA(Romeo)': 'assets/icon/SLMTODA.png',
  'PPEMPBRTODA(Soldiers)': 'assets/icon/PPMPEBRTODA.png',
  'PPEMPBRTODA(Central)': 'assets/icon/PPMPEBRTODA.png',
  'SLDECTODA(De Castro)': 'assets/icon/SLDECTODA.png',
  'SLDECTODA(Meleguas)': 'assets/icon/SLDECTODA.png',
  'FERTODA(Ortigas)': 'assets/icon/FERTODA.png',
  'FERTODA(E Bank)': 'assets/icon/FERTODA.png',
  'FERTODA(Block 19)': 'assets/icon/FERTODA.png',
  'FERTODA(Cainta)': 'assets/icon/FERTODA.png',
  'SLEOMTODA(Super 8)': 'assets/icon/SLEOMTODA.png',
  'PPMSFLWFMTODA(Central)': 'assets/icon/PPMSFLWFMTODA.png',
  'PPMSFLWFMTODA(W Bank)': 'assets/icon/PPMSFLWFMTODA.png',
  'EPSTODA(Crossing)': 'assets/icon/EPSTODA.png',
  'EPSTODA(Evangelista)': 'assets/icon/EPSTODA.png',
  'MERSANTODA(Plaza)': 'assets/icon/MERSANTODA.png',
  'MERSANTODA(Puregold)': 'assets/icon/MERSANTODA.png',
  'MERSANTODA(Robinsons)': 'assets/icon/MERSANTODA.png',
  'MERSANTODA(Consolacion)': 'assets/icon/MERSANTODA.png',
  'MERSANTODA(Domingo)': 'assets/icon/MERSANTODA.png',
  'BAMATODA(Center)': 'assets/icon/BAMATODA.png',
  'BAMATODA(Another)': 'assets/icon/BAMATODA.png',
  'BISPPTODA': 'assets/icon/BISPPTODA.png',
  'BITODA': 'assets/icon/BITODA.png',
  'BIUTODA': 'assets/icon/BIUTODA.png',
  'BMPTODA(Banaag)': 'assets/icon/BMPTODA.png',
  'BMPTODA(Masilang)': 'assets/icon/BMPTODA.png',
  'BMPTODA(Sto Nino)': 'assets/icon/BMPTODA.png',
  'BMPTODA(Sta Monica)': 'assets/icon/BMPTODA.png',
  'BSJTODA(Center)': 'assets/icon/BSJTODA.png',
  'BSJTODA(Another)': 'assets/icon/BSJTODA.png',
  'CROSSNATODA': 'assets/icon/CROSSNATODA.png',
  'DODGEVILLETODA': 'assets/icon/DODGEVILLETODA.png',
  'ESCPPTODA': 'assets/icon/ESCPPTODA.png',
  'ISKATODA(Center)': 'assets/icon/ISKATODA.png',
  'ISKATODA(Another)': 'assets/icon/ISKATODA.png',
  'JASSTODA': 'assets/icon/JASSTODA.png',
  'JAYNITHSTODA': 'assets/icon/JAYNITHSTODA.png',
  'KAPTODA': 'assets/icon/KAPTODA.png',
  'VIAKARTODA': 'assets/icon/VIAKARTODA.png',
  'KATODA(San Rafael)': 'assets/icon/KATODA.png',
  'KATODA(San Ignacio)': 'assets/icon/KATODA.png',
  'LJSRTODA': 'assets/icon/LJSRTODA.png',
  'MPMSTODA': 'assets/icon/MPMSTODA.png',
  'MRPTODA(Center)': 'assets/icon/MRPTODA.png',
  'MRPTODA(Another)': 'assets/icon/MRPTODA.png',
  'OTODA': 'assets/icon/OTODA.png',
  'GVPPMTODA(Center)': 'assets/icon/GVPPMTODA.png',
  'GVPPMTODA(Another)': 'assets/icon/GVPPMTODA.png',
  'PARTODA': 'assets/icon/PARTODA.png',
  'PPRMSSPTODA': 'assets/icon/PPRMSSPTODA.png',
  'PATODA': 'assets/icon/PATODA.png',
  'PCMSTODA': 'assets/icon/PCMSTODA.png',
  'PCMTODA': 'assets/icon/PCMTODA.png',
  'PITODA(A Flores)': 'assets/icon/PITODA.png',
  'PITODA(Pag Asa)': 'assets/icon/PITODA.png',
  'PLTODA': 'assets/icon/PLTODA.png',
  'PMATODA': 'assets/icon/PMATODA.png',
  'PNSTODA(Center)': 'assets/icon/PNSTODA.png',
  'PNSTODA(Another)': 'assets/icon/PNSTODA.png',
  'PPMARTODA(Center)': 'assets/icon/PPMARTODA.png',
  'PPMARTODA(Another)': 'assets/icon/PPMARTODA.png',
  'PPMTODA(Center)': 'assets/icon/PPMTODA.png',
  'PPMTODA(Another)': 'assets/icon/PPMTODA.png',
  'PROTODA': 'assets/icon/PROTODA.png',
  'PRPATODA': 'assets/icon/PRPATODA.png',
  'PSBTODA': 'assets/icon/PSBTODA.png',
  'RETODA': 'assets/icon/RETODA.png',
  'PMMBTODA(Center)': 'assets/icon/PMMBTODA.png',
  'PMMBTODA(Another)': 'assets/icon/PMMBTODA.png',
  'S.TODA': 'assets/icon/S.TODA.png',
  'SAKTODA(Center)': 'assets/icon/SAKTODA.png',
  'SAKTODA(Another)': 'assets/icon/SAKTODA.png',
  'SAMCATODA(Center)': 'assets/icon/SAMCATODA.png',
  'SAMCATODA(Another)': 'assets/icon/SAMCATODA.png',
  'SANPATODA(Corner)': 'assets/icon/SANPATODA.png',
  'SANPATODA(Market)': 'assets/icon/SANPATODA.png',
  'SNCPPTODA': 'assets/icon/SNCPPTODA.png',
  'SACPTODA': 'assets/icon/SACPTODA.png',
  'SMPSSTODA': 'assets/icon/SMPSSTODA.png',
  'SSMTODA(Sagad)': 'assets/icon/SSMTODA.png',
  'SSMTODA(East Raya)': 'assets/icon/SSMTODA.png',
  'ST.JOBTODA(Center)': 'assets/icon/STJOBTODA.png',
  'ST.JOBTODA(Another)': 'assets/icon/STJOBTODA.png',
  'SMART-LSTODA': 'assets/icon/SMART-LSTODA.png',
  'SUMTODA': 'assets/icon/SUMTODA.png',
  'SVRPMTODA(Center)': 'assets/icon/SVRPMTODA.png',
  'SVRPMTODA(Another)': 'assets/icon/SVRPMTODA.png',
  'UPPTODA': 'assets/icon/UPPTODA.png',
  'VATODA': 'assets/icon/VATODA.png',
  'VRTODA': 'assets/icon/VRTODA.png'
};
@Component({
  selector: 'app-folder',
  templateUrl: './folder.page.html',
  styleUrls: ['./folder.page.scss'],
  standalone: false,
})
export class FolderPage implements OnInit, AfterViewInit, OnDestroy {
  private watchId: number | null = null;
private _isManualLocationSet = false; // Private backing field
private currentBouncingMarker: google.maps.Marker | null = null; // ← Add this line
// Public getter
public get isManualLocationSet(): boolean {
  return this._isManualLocationSet;
}
  // Replace the existing routePolylines with:
  // Change from private to public
  private backButtonSubscription: any;
private lastTimeBackPress = 0;
private timePeriodToExit = 2000; // 2 seconds

private getUserIdentifier(): string | null {
  // ✅ Single source of truth: identifier can be email OR phone
  // Keep compatibility with older key names if you used them before
  return (
    localStorage.getItem('userEmail') ||
    localStorage.getItem('user_email') ||
    null
  );
}
  private terminalsByToda: { [key: string]: any[] } = {};
  public directionsRenderers: google.maps.DirectionsRenderer[] = [];
  private activeRouteRenderers: google.maps.DirectionsRenderer[] = [];
  public showRouteDisclaimer: boolean = false;
  private activeRoutes: google.maps.DirectionsResult[] = [];
  private directionsService!: google.maps.DirectionsService;
  private directionsRenderer!: google.maps.DirectionsRenderer;
  directionsResponse: google.maps.DirectionsResult | null = null;
  private destinationMarker: google.maps.Marker | null = null;
  // Inside your component class (e.g., FolderPage)
private customEpsTodaRoute: google.maps.LatLngLiteral[] = [
  { lat: 14.622918, lng: 121.083738 }, // EPSTODA Terminal 1
  { lat: 14.618823835724877, lng: 121.08192600196536 }, // Intermediate point 1
  { lat: 14.617266, lng: 121.086282 }, // Intermediate point 2
  { lat: 14.612243210923753, lng: 121.08726930093623 }, // Intermediate point 3
  { lat: 14.609881, lng: 121.091681 }  // EPSTODA Terminal 2
];
private customPsssrmTodaRoute: google.maps.LatLngLiteral[] = [
  // Terminal A
  { lat: 14.575454885101093, lng: 121.09852852749411 }, 
  // Intermediate points (add actual tricycle path)
  { lat: 14.572968377796553, lng: 121.1002756815282 },     
  { lat: 14.571077519628119, lng: 121.09862757013894 },    
  { lat: 14.571332130838426, lng: 121.09747097265338 },    
  { lat: 14.571033513390473, lng: 121.09150219577226 },    
  { lat: 14.571892988968703, lng: 121.08784159579051 },     
  { lat: 14.568467642939524, lng: 121.08598903523378 },     
  { lat: 14.565651912366757, lng: 121.08561202355118 },     
  { lat: 14.564411359988846, lng: 121.08507149580076 },     
  { lat: 14.562393602139103, lng: 121.08459278850512 },     
  { lat: 14.559780745504915, lng: 121.08368165166897 },     
  // Terminal B
  { lat: 14.558096170985763, lng: 121.08303137203855 }  
];
 
private destinationIcon = {
  url: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png',
  scaledSize: new google.maps.Size(40, 40)
};
  public folder!: string;
  startingLocation: string = '';  // Default empty value
  destination: string = '';       // Default empty value
  currentSection = 'todaList';
  km = 0
  fare: number = 0;
  baseKm: number = 1;
  baseRate = 13;
  additionalRate: number = 0; 
  perKm: number = 1;
  discount: number = 0;
  // Paki palitan nalang yung any rush update lang kasi.
  currentLocation:{ lat: number; lng: number } = {
    lat: 0,
    lng: 0
  };
  searchedLocation:{ lat: number; lng: number } = {
    lat: 0,
    lng: 0
  };
  private navCtrl = inject(NavController);
  private router = inject(Router);
 
selectedFromHistory: boolean = false;
showGpsInstructions = false;
hasSeenGpsInstructions = false;

  @ViewChild('modal') modal!: IonModal;
  @ViewChild('fareModal') fareModal!: IonModal;
  @ViewChild('searchBox', { static: false }) searchBox!: ElementRef;
  @ViewChild('newSearchBox', { static: false }) newSearchBoxRef!: ElementRef;
@ViewChild('mapContainer', { static: false }) mapContainer!: ElementRef;

  selectedPlace: any; // Store selected place details
  places: any[] = []; // Declare places array

  selectedPlaceName: string = ''; // ✅ Declare the variable

  autocomplete: any;

  initAutocomplete() {
    if (!this.searchBox) {
      console.error('SearchBox not found!');
      return;
    }
  
    const options = {
      types: ['geocode'], // Suggest locations only
      componentRestrictions: { country: 'PH' }, // Restrict to the Philippines
      bounds: new google.maps.LatLngBounds(
        new google.maps.LatLng(14.5310, 121.0000), // SW Corner of Pasig
        new google.maps.LatLng(14.6000, 121.1000)  // NE Corner of Pasig
      ),
      strictBounds: true
    };
  
    // Initialize Google Places Autocomplete using a SearchBox
    this.autocomplete = new google.maps.places.SearchBox(this.searchBox.nativeElement, options);
  
    // Bias autocomplete results to the currently loaded map
    if (this.map) {
      this.autocomplete.bindTo("bounds", this.map);
    }
  
    // Listen for changes when a place is selected
   this.autocomplete.addListener("places_changed", () => {
  const places = this.autocomplete.getPlaces();
      
      if (!places || places.length === 0) {
        console.warn("No places found.");
        return;
      }
  
      const place = places[0]; // Get first selected place
      const selectedLocation = places[0].geometry.location;
      console.log("Selected Place:", place);
      const latitude = selectedLocation.lat();
      const longitude = selectedLocation.lng();
      this.stopLocationTracking();
      this.searchedLocation = {
        lat: latitude,
        lng: longitude
      };

      this.selectedPlaceName = place.formatted_address;
  
      if (!place.geometry) {
        console.warn("Place has no geometry.");
        return;
      }
  
      // Call function to process the selected place
      this.selectPlace(place);
    });
  
    console.log("Google Places Autocomplete Initialized with SearchBox.");
  }
  
  isNewSearchExpanded = false;
newSearchQuery = '';



public toggleLocationMode() {

  if (this.isManualLocationSet) {
    this.startLocationTracking();
  } else {
    this.stopLocationTracking();
  }
}

dontShowAgain = false;

confirmGpsInstructions() {
  this.showGpsInstructions = false;
  this.hasSeenGpsInstructions = true;
  
  if (this.dontShowAgain) {
    localStorage.setItem('hasSeenGpsInstructions', 'true');
  }
  
  // Proceed with location tracking
  this.startLocationTracking();
}

toggleNewSearchPanel() {
  this.isNewSearchExpanded = !this.isNewSearchExpanded;
}

onNewSearch() {
  console.log('Searching for:', this.newSearchQuery);

  if (this.selectedPlace) {
    this.currentAddress = this.newSearchQuery; // Update the toggle button text
    console.log('Selected Place:', this.selectedPlace);
  } else {
    console.log('No place selected');
  }

  // Implement additional search functionality here if needed
}



searchQuery: string = '';
showPopup: boolean = false; // Controls pop-up visibility



onSearchInput() {
  console.log('User is typing:', this.searchQuery);
  // Implement real-time filtering here if needed
}

haversineDistance(loc1: { lat: number; lng: number }, loc2: { lat: number; lng: number }): number {
  const R = 6371; // Radius of the Earth in kilometers

  // Convert latitude and longitude from degrees to radians
  const lat1 = loc1.lat * (Math.PI / 180);
  const lat2 = loc2.lat * (Math.PI / 180);
  const dLat = lat2 - lat1;
  const dLng = (loc2.lng - loc1.lng) * (Math.PI / 180);

  // Calculate the 'straight' distance across latitude and longitude
  const horizontalDistance = R * Math.abs(dLng) * Math.cos((lat1 + lat2) / 2);
  const verticalDistance = R * Math.abs(dLat);

  // Manhattan distance
  const manhattanDistance = horizontalDistance + verticalDistance;

  return manhattanDistance; // Distance in kilometers
}
async onSearch() {
  if (!this.searchQuery.trim()) {
    alert("Please enter a location.");
    return;
  }

  // Check if a terminal is selected
  if (!this.selectedTerminal) {
    alert("Please select a TODA terminal first.");
    return;
  }

  try {
    // Clear previous destination marker if exists
    if (this.destinationMarker) {
      this.destinationMarker.setMap(null);
    }

    // Find the terminal coordinates from todaTerminals array
    const terminal = this.todaTerminals.find(t => t.name === this.selectedTerminal.name);
    if (!terminal) {
      alert("Selected terminal not found.");
      return;
    }

   
    // Use terminal location instead of current location
    const terminalLocation = { lat: terminal.lat, lng: terminal.lng };

    // Use Directions API for road distance from terminal to destination
    this.km = await this.computeRoadDistance(terminalLocation, this.searchedLocation);
    this.km = Math.ceil(this.km);

    // Add bright blue destination marker (using Google Maps blue)
    this.destinationMarker = new google.maps.Marker({
      position: this.searchedLocation,
      map: this.map,
      title: 'Destination',
      icon: {
        url: 'https://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        scaledSize: new google.maps.Size(40, 40)
      },
      animation: google.maps.Animation.DROP
    });

    // Fare calculation
    if (this.km <= this.baseKm) {
      this.fare = this.baseRate - this.discount;
      this.additionalRate = 0;
    } else {
      const extraKm = this.km - this.baseKm;
      const wholeKm = Math.floor(extraKm);
      const remainingKm = extraKm - wholeKm;
      const wholeKmFare = wholeKm * this.perKm;
      const remainingKmFare = remainingKm > 0 ? this.perKm : 0;
      this.additionalRate = wholeKmFare + remainingKmFare;
      this.fare = (this.baseRate + this.additionalRate) - this.discount;
    }

    // Parse discount to 2 decimals only here
    this.discount = parseFloat(this.discount.toFixed(2));

    // Store and display route
    await this.storeRouteForDisplay();
    this.showPopup = true;
    this.saveSearchHistory();
  } catch (error) {
    console.error("Error computing road distance:", error);
    // Fallback to straight-line distance if API fails
    const terminal = this.todaTerminals.find(t => t.name === this.selectedTerminal.name);
    if (terminal) {
      this.km = this.haversineDistance(
        { lat: terminal.lat, lng: terminal.lng }, 
        this.searchedLocation
      );
    }
    alert("Road distance failed. Using straight-line distance instead.");

    // Still show destination marker even in fallback mode
    this.destinationMarker = new google.maps.Marker({
      position: this.searchedLocation,
      map: this.map,
      title: 'Destination (Approximate)',
      icon: {
        url: 'https://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        scaledSize: new google.maps.Size(40, 40)
      }
    });
  }
}
private async storeRouteForDisplay() {
  if (!this.selectedTerminal || !this.directionsService) return;

  const terminal = this.todaTerminals.find(t => t.name === this.selectedTerminal.name);
  if (!terminal) return;

  return new Promise<void>((resolve, reject) => {
    this.directionsService.route(
      {
        origin: new google.maps.LatLng(terminal.lat, terminal.lng),
        destination: new google.maps.LatLng(this.searchedLocation.lat, this.searchedLocation.lng),
        travelMode: google.maps.TravelMode.DRIVING,
      },
      (response, status) => {
        if (status === google.maps.DirectionsStatus.OK) {
          this.directionsResponse = response;
          resolve();
        } else {
          reject(`Directions API error: ${status}`);
        }
      }
    );
  });
}


private async computeRoadDistance(origin: { lat: number; lng: number }, destination: { lat: number; lng: number }): Promise<number> {
  if (typeof google === 'undefined' || !google.maps || !google.maps.DirectionsService) {
    throw new Error("Google Maps API not loaded.");
  }
  
  return new Promise((resolve, reject) => {
    if (!this.directionsService) {
      reject("DirectionsService not initialized.");
      return;
    }

    this.directionsService.route(
      {
        origin: new google.maps.LatLng(origin.lat, origin.lng),
        destination: new google.maps.LatLng(destination.lat, destination.lng),
        travelMode: google.maps.TravelMode.DRIVING,
        provideRouteAlternatives: false
      },
      (response, status) => {
        if (status === google.maps.DirectionsStatus.OK && response?.routes[0]?.legs[0]?.distance) {
          const distanceInKm = response.routes[0].legs[0].distance.value / 1000;
          resolve(distanceInKm);
        } else {
          reject(`Unable to calculate road distance: ${status}`);
        }
      }
    );
  });
}

closePopup() {
  this.showPopup = false;

  if (this.directionsResponse && this.directionsRenderer && this.map) {
    this.directionsRenderer.setMap(this.map);
    this.directionsRenderer.setDirections(this.directionsResponse);

    const bounds = new google.maps.LatLngBounds();
    this.directionsResponse.routes[0].legs.forEach(leg => {
      bounds.extend(leg.start_location);
      bounds.extend(leg.end_location);
    });
    this.map.fitBounds(bounds);
  }

  // 🔒 Prevent terminal from resetting after history selection
  setTimeout(() => {
    this.selectedFromHistory = false;
  }, 500);
}


  // 🔹 UI & Modal Properties
  name: string = '';
  isBottomBarVisible = false;
  selectedTerminal: any = null;

  // 🔹 Search Panel & Tabs
  isSearchExpanded = false;
  activeTab: string = 'recents';
  recentPlaces: string[] = ['Place 1', 'Place 2', 'Place 3'];
  todaList: string[] = ['Terminal 1', 'Terminal 2', 'Terminal 3'];

  // 🔹 Google Maps Properties
  map!: google.maps.Map | undefined;
  userMarker!: google.maps.Marker | undefined;
  geocoder = new google.maps.Geocoder();
  currentAddress: string = "Fetching location...";
  center = { lat: 14.5736, lng: 121.0785 };
  
private getCoordinatesFromAddress(address: string): Promise<{ lat: number; lng: number }> {
  return new Promise((resolve, reject) => {
    this.geocoder.geocode({ address }, (results, status) => {
      if (status === 'OK' && results?.[0]?.geometry?.location) {
        const location = results[0].geometry.location;
        resolve({
          lat: location.lat(),
          lng: location.lng()
        });
      } else {
        reject(`Geocoding failed for address: ${address}. Status: ${status}`);
      }
    });
  });
}

  // 🔹 Map Loading Indicator
  isLoading = true;
  mapLoaded = new Subject<boolean>(); // Observable to track map loading status

  // REPLACE the todaTerminals array (starting around line 644) with this:

todaTerminals = [
  { name: 'DEUNITODA(Sta. Lucia)', lat: 14.619201815108473, lng: 121.09723063174908 },
  { name: 'DEUNITODA(Southville)', lat: 14.61689154190142, lng: 121.09293592246127 },
  { name: 'DEUNITODA(48 Mariano)', lat: 14.61289400339855, lng: 121.09520962141617 },
  { name: 'DOCTODA(Octagon)', lat: 14.609662278823357, lng: 121.09198195209723 },
  { name: 'DOCTODA(ADR)', lat: 14.610250994241396, lng: 121.09220424054936 },
  { name: 'VAMTODA(Alfonso)', lat: 14.590237095781466, lng: 121.09529762178033 },
  { name: 'FHNAPICOTODA(Lifehomes)', lat: 14.590203529112124, lng: 121.09345029464683 },
  { name: 'MPGVTODA(Gate 1)', lat: 14.606844656056433, lng: 121.09457173521662 },
  { name: 'MPGVTODA(Hawaii)', lat: 14.61552870244407, lng: 121.1017307232622 },
  { name: 'MAMTODA(Mabini)', lat: 14.599053629520588, lng: 121.0943190143383 },
  { name: 'MAMTODA(Feliciano)', lat: 14.599370196840724, lng: 121.09527519415442 },
  { name: 'MLKPPTODA(Magsaysay)', lat: 14.603334583908504, lng: 121.09368820976732 },
  { name: 'MLKPPTODA(K Center)', lat: 14.605079218368171, lng: 121.10511199789724 },
  { name: 'PROFMATODA(Rainforest)', lat: 14.575956174183025, lng: 121.0974932637451 },
  { name: 'PROFMATODA(Palengke)', lat: 14.558005401739523, lng: 121.08265270048219 },
  { name: 'PROFMATODA(Legaspi)', lat: 14.578575357724935, lng: 121.0972709928782 },
  { name: 'PROFMATODA(Eusebio)', lat: 14.577869148465524, lng: 121.08321579349472 },
  { name: 'PROFMATODA(Stella Maris)', lat: 14.573505620414403, lng: 121.09981750287564 },
  { name: 'PRRESJMTODA(PCGH)', lat: 14.558074398345635, lng: 121.08248264942256 },
  { name: 'PRRESJMTODA(Rose St)', lat: 14.57216101900279, lng: 121.09969067341464 },
  { name: 'PRRESJMTODA(Eusebio)', lat: 14.571107726144346, lng: 121.09456716271245 },
  { name: 'PSSSRMTODA(Tulay)', lat: 14.575422290509955, lng: 121.09859421916133 },
  { name: 'PSSSRMTODA(MI SG)', lat: 14.559984366554534, lng: 121.08383706089745 },
  { name: 'SANSETODA(Urbano)', lat: 14.55703823872647, lng: 121.08613914254236 },
  { name: 'SANSETODA(Palengke)', lat: 14.557803060014471, lng: 121.08462638643343 },
  { name: 'JABSONTODA(Velasco)', lat: 14.55703823872647, lng: 121.08613914254236 },
  { name: 'BESCPPTODA(Esguerra)', lat: 14.56016264325384, lng: 121.08775856381747 },
  { name: 'NAGTODA(Sunrise)', lat: 14.539455768701322, lng: 121.10227760526409 },
  { name: 'NAGTODA(Novo)', lat: 14.557837860827373, lng: 121.0844931448594 },
  { name: 'NAGTODA(Eusebio)', lat: 14.546462747957563, lng: 121.10692482900524 },
  { name: 'RAMTODA(Palengke)', lat: 14.557802096578735, lng: 121.08451363501636 },
  { name: 'RAMTODA(Heroes)', lat: 14.54045993234287, lng: 121.10570523110316 },
  { name: 'SPRGEVTODA(Central)', lat: 14.55773479510892, lng: 121.08279743896516 },
  { name: 'SLRPPTODA(Central)', lat: 14.55773479510892, lng: 121.08279743896516 },
  { name: 'SLRPPTODA(Taytay)', lat: 14.543174933962572, lng: 121.10783860750426 },
  { name: 'PPCTODA(Central)', lat: 14.55781048640976, lng: 121.08459260230197 },
  { name: 'PPCTODA(Urbano)', lat: 14.557010672310362, lng: 121.08613525043376 },
  { name: 'PPCTODA(Centennial)', lat: 14.545235386844885, lng: 121.10193205646229 },
  { name: 'PPCTODA(Bamboo)', lat: 14.54339724416997, lng: 121.09806329656158 },
  { name: 'MIPTODA(Palengke)', lat: 14.55781048640976, lng: 121.08459260230197 },
  { name: 'MIPTODA(Sandoval)', lat: 14.551066925896656, lng: 121.10126479127265 },
  { name: 'MIPTODA(Ilugin)', lat: 14.55301924062535, lng: 121.10044939980216 },
  { name: 'PPEATODA(Palengke)', lat: 14.55781048640976, lng: 121.08459260230197 },
  { name: 'PPEATODA(Eusebio)', lat: 14.537842806777467, lng: 121.10523608406164 },
  { name: 'ATODA(Palengke)', lat: 14.55781048640976, lng: 121.08459260230197 },
  { name: 'ATODA(Acacia)', lat: 14.55493959052337, lng: 121.08886136564901 },
  { name: 'PPFHTODA(Palengke)', lat: 14.557838834361958, lng: 121.08272762498841 },
  { name: 'PPFHTODA(FishPort)', lat: 14.547834519081544, lng: 121.11906073542028 },
  { name: 'EAPPPTODA(Palengke)', lat: 14.55781048640976, lng: 121.08459260230197 },
  { name: 'EAPPPTODA(Super8)', lat: 14.539657451306477, lng: 121.1055067646449 },
  { name: 'JRFMTODA(Rosario)', lat: 14.589401, lng: 121.092443 },
  { name: 'JRFMTODA(Jennys)', lat: 14.573707295448058, lng: 121.1006797984035 },
  { name: 'FEMPATTODA(Ortigas)', lat: 14.591009425533423, lng: 121.09423629760241 },
  { name: 'PRTMGTODA(Greenland)', lat: 14.583611712822137, lng: 121.09162222654788 },
  { name: 'PRTMGTODA(Raymundo)', lat: 14.588848956005512, lng: 121.08996078284338 },
  { name: 'PRTMGTODA(Sixto)', lat: 14.589799222299822, lng: 121.08515397520073 },
  { name: 'PRTMGTODA(Pasco)', lat: 14.579353602928268, lng: 121.08241125069146 },
  { name: 'PRTMGTODA(Quezon)', lat: 14.58784772674758, lng: 121.08900416416337 },
  { name: 'BRFMTODA(Ortigas)', lat: 14.591172421787654, lng: 121.09439895704924 },
  { name: 'BRFMTODA(E Bank)', lat: 14.590335469239761, lng: 121.09317627900968 },
  { name: 'TAPCJRTODA(EAR)', lat: 14.59140023461374, lng: 121.08648908366483 },
  { name: 'TAPCJRTODA(Jabson)', lat: 14.594873946296811, lng: 121.08902286598276 },
  { name: 'RSGSPSTODA(Paseo)', lat: 14.596031008588021, lng: 121.10939127167808 },
  { name: 'RVTODA(Riverside)', lat: 14.588572094537826, lng: 121.10359289845955 },
  { name: 'SMEOTODAPC(SM East)', lat: 14.587365148509484, lng: 121.10461675943144 },
  { name: 'SLMTODA(Mabuhay)', lat: 14.579523380018431, lng: 121.10115760891001 },
  { name: 'SLMTODA(Romeo)', lat: 14.578925042819142, lng: 121.1070117450637 },
  { name: 'PPEMPBRTODA(Soldiers)', lat: 14.576339290919877, lng: 121.10135097567525 },
  { name: 'PPEMPBRTODA(Central)', lat: 14.557725236477037, lng: 121.08262905739124 },
  { name: 'SLDECTODA(De Castro)', lat: 14.589023166462624, lng: 121.09724974453863 },
  { name: 'SLDECTODA(Meleguas)', lat: 14.584861690196822, lng: 121.09876929091182 },
  { name: 'FERTODA(Ortigas)', lat: 14.589457, lng: 121.093505 },
  { name: 'FERTODA(E Bank)', lat: 14.590010542020838, lng: 121.09560012643547 },
  { name: 'FERTODA(Block 19)', lat: 14.57378853097867, lng: 121.10333632387307 },
  { name: 'FERTODA(Cainta)', lat: 14.569675324547536, lng: 121.10724549629525 },
  { name: 'SLEOMTODA(Super 8)', lat: 14.587865364440285, lng: 121.10279223675616 },
  { name: 'PPMSFLWFMTODA(Central)', lat: 14.573231854507501, lng: 121.10077243905346 },
  { name: 'PPMSFLWFMTODA(W Bank)', lat: 14.557848510928208, lng: 121.082777773261 },
  { name: 'EPSTODA(Crossing)', lat: 14.610242859000733, lng: 121.09109467280912 },
  { name: 'EPSTODA(Evangelista)', lat: 14.623572826212811, lng: 121.08536547466115 },
  { name: 'MERSANTODA(Plaza)', lat: 14.568225313343746, lng: 121.08606735159766 },
  { name: 'MERSANTODA(Puregold)', lat: 14.567333441284417, lng: 121.09476821530457 },
  { name: 'MERSANTODA(Robinsons)', lat: 14.567089761138758, lng: 121.09405097666674 },
  { name: 'MERSANTODA(Consolacion)', lat: 14.567310330051475, lng: 121.09534814052175 },
  { name: 'MERSANTODA(Domingo)', lat: 14.568135801472899, lng: 121.0869563730295 },
  
  // NEW TERMINALS FROM PDF - CORRECTED COORDINATES
  { name: 'BAMATODA(Center)', lat: 14.558787499414382, lng: 121.08054484965544 },
  { name: 'BAMATODA(Another)', lat: 14.556294974611355, lng: 121.08274589754204 },
  { name: 'BISPPTODA', lat: 14.562936341111135, lng: 121.06967041098223 },
  { name: 'BITODA', lat: 14.562936341111135, lng: 121.06967041098223 },
  { name: 'BIUTODA', lat: 14.565815318491932, lng: 121.07093844672933 },
  { name: 'BMPTODA(Banaag)', lat: 14.5637627, lng: 121.0650528 },
  { name: 'BMPTODA(Masilang)', lat: 14.56351, lng: 121.065035 },
  { name: 'BMPTODA(Sto Nino)', lat: 14.5658476, lng: 121.0597531 },
  { name: 'BMPTODA(Sta Monica)', lat: 14.5671499, lng: 121.0553311 },
  { name: 'BSJTODA(Center)', lat: 14.553390011288073, lng: 121.07190175797706 },
  { name: 'BSJTODA(Another)', lat: 14.554887825712944, lng: 121.06565294390272 },
  { name: 'CROSSNATODA', lat: 14.576823615628092, lng: 121.08521948496517 },
  { name: 'DODGEVILLETODA', lat: 14.567666745199958, lng: 121.080692189095 },
  { name: 'ESCPPTODA', lat: 14.56102537937855, lng: 121.08727806066857 },
  { name: 'ISKATODA(Center)', lat: 14.549390964422537, lng: 121.09215341291008 },
  { name: 'ISKATODA(Another)', lat: 14.550913296158248, lng: 121.07609716338168 },
  { name: 'JASSTODA', lat: 14.558885648603193, lng: 121.07301326663932 },
  { name: 'JAYNITHSTODA', lat: 14.560186439809373, lng: 121.08391134970597 },
  { name: 'KAPTODA', lat: 14.562551960934215, lng: 121.07432584866308 },
  { name: 'VIAKARTODA', lat: 14.558595376211086, lng: 121.08297218765995 },
  // KATODA - CORRECTED COORDINATES (14°34'23"N 121°03'30"E)
  { name: 'KATODA(San Rafael)', lat: 14.572639, lng: 121.058333 },
  { name: 'KATODA(San Ignacio)', lat: 14.573056, lng: 121.058333 },
  { name: 'LJSRTODA', lat: 14.559572416858991, lng: 121.07338005790069 },
  { name: 'MPMSTODA', lat: 14.558595376211086, lng: 121.08297218765995 },
  { name: 'MRPTODA(Center)', lat: 14.55656682099179, lng: 121.07858582452609 },
  { name: 'MRPTODA(Another)', lat: 14.55656682099179, lng: 121.07858582452609 },
  { name: 'OTODA', lat: 14.573001631723812, lng: 121.06368243420616 },
  { name: 'GVPPMTODA(Center)', lat: 14.560195089918473, lng: 121.08395589531204 },
  { name: 'GVPPMTODA(Another)', lat: 14.558595376211086, lng: 121.08297218765995 },
  { name: 'PARTODA', lat: 14.561323338981966, lng: 121.07636755517184 },
  { name: 'PPRMSSPTODA', lat: 14.557905557992731, lng: 121.08271072812084 },
  { name: 'PATODA', lat: 14.557905557992731, lng: 121.08271072812084 },
  { name: 'PCMSTODA', lat: 14.558595376211086, lng: 121.08297218765995 },
  { name: 'PCMTODA', lat: 14.558595376211086, lng: 121.08297218765995 },
  // PITODA - CORRECTED COORDINATES (14°34'00"N 121°04'34"E)
  { name: 'PITODA(A Flores)', lat: 14.566667, lng: 121.076111 },
  { name: 'PITODA(Pag Asa)', lat: 14.573056, lng: 121.080833 },
  { name: 'PLTODA', lat: 14.558595376211086, lng: 121.08297218765995 },
  { name: 'PMATODA', lat: 14.558595376211086, lng: 121.08297218765995 },
  { name: 'PNSTODA(Center)', lat: 14.581196828211255, lng: 121.08689437685877 },
  { name: 'PNSTODA(Another)', lat: 14.581196828211255, lng: 121.08689437685877 },
  { name: 'PPMARTODA(Center)', lat: 14.560195089918473, lng: 121.08395589531204 },
  { name: 'PPMARTODA(Another)', lat: 14.560195089918473, lng: 121.08395589531204 },
  { name: 'PPMTODA(Center)', lat: 14.558595376211086, lng: 121.08297218765995 },
  { name: 'PPMTODA(Another)', lat: 14.558595376211086, lng: 121.08297218765995 },
  // PROTODA - CORRECTED COORDINATES (14°33'54"N 121°04'33"E)
  { name: 'PROTODA', lat: 14.565, lng: 121.075833 },
  { name: 'PRPATODA', lat: 14.572812669028872, lng: 121.0830866445697 },
  { name: 'PSBTODA', lat: 14.575763763200456, lng: 121.05892956768379 },
  { name: 'RETODA', lat: 14.558595376211086, lng: 121.08297218765995 },
  { name: 'PMMBTODA(Center)', lat: 14.558595376211086, lng: 121.08297218765995 },
  { name: 'PMMBTODA(Another)', lat: 14.558595376211086, lng: 121.08297218765995 },
  { name: 'S.TODA', lat: 14.555321, lng: 121.079310 },
  { name: 'SAKTODA(Center)', lat: 14.551109272090695, lng: 121.08683167146927 },
  { name: 'SAKTODA(Another)', lat: 14.550913296158248, lng: 121.07609716338168 },
  { name: 'SAMCATODA(Center)', lat: 14.566619601949299, lng: 121.07690410896794 },
  { name: 'SAMCATODA(Another)', lat: 14.5668873538246, lng: 121.09874798198298 },
  // SANPATODA - CORRECTED COORDINATES (14°33'39"N 121°04'39"E)
  { name: 'SANPATODA(Corner)', lat: 14.560833, lng: 121.0775 },
  { name: 'SANPATODA(Market)', lat: 14.563611, lng: 121.084722 },
  { name: 'SNCPPTODA', lat: 14.562460526095034, lng: 121.09246428381496 },
  { name: 'SACPTODA', lat: 14.563937888745823, lng: 121.08470269202435 },
  { name: 'SMPSSTODA', lat: 14.560195089918473, lng: 121.08395589531204 },
  // SSMTODA - CORRECTED COORDINATES (14°33'52"N 121°05'06"E)
  { name: 'SSMTODA(Sagad)', lat: 14.564444, lng: 121.085 },
  { name: 'SSMTODA(East Raya)', lat: 14.564444, lng: 121.075833 },
  { name: 'ST.JOBTODA(Center)', lat: 14.5494955, lng: 121.0789071 },
  { name: 'ST.JOBTODA(Another)', lat: 14.550913296158248, lng: 121.07609716338168 },
  { name: 'SMART-LSTODA', lat: 14.559398552190801, lng: 121.08469692696214 },
  // SUMTODA - CORRECTED COORDINATES (14°33'20"N 121°04'26"E)
  { name: 'SUMTODA', lat: 14.555556, lng: 121.073889 },
  { name: 'SVRPMTODA(Center)', lat: 14.559925310099199, lng: 121.08473043148192 },
  { name: 'SVRPMTODA(Another)', lat: 14.560195089918473, lng: 121.08395589531204 },
  // UPPTODA - CORRECTED COORDINATES (14°34'45"N 121°04'42"E)
  { name: 'UPPTODA', lat: 14.579167, lng: 121.078333 },
  { name: 'VATODA', lat: 14.557285699999285, lng: 121.08464865889692 },
  { name: 'VRTODA', lat: 14.554995027317761, lng: 121.08000470195864 }
];

   feedbackMessage: string = '';

 constructor(
  private activatedRoute: ActivatedRoute,
  private cdRef: ChangeDetectorRef,
  private platform: Platform,
  private http: HttpClient,
  private toastCtrl: ToastController,
  private alertController: AlertController
  
   ) {}

  dismissModal() {
    this.modal.dismiss();
    cssTrigger: 'open-modal'
  }

  initializeNewNewAutocomplete() {
    if (!this.newSearchBoxRef) return;

    const autocomplete = new google.maps.places.Autocomplete(this.newSearchBoxRef.nativeElement, {
      types: ['geocode'],
      componentRestrictions: { country: 'PH' } // Restrict results to the Philippines
    });

    autocomplete.addListener('place_changed', () => {
      const place = autocomplete.getPlace();
      if (place && place.formatted_address) {
        this.newSearchQuery = place.formatted_address; // Update search box text
        this.selectedPlace = place; // Store place details
      }
    });
  }
  fullSearchHistory: any[] = [];
  ngOnInit() { 
    this.hasSeenGpsInstructions = localStorage.getItem('hasSeenGpsInstructions') === 'true';
    // Fetch route parameters
   this.loadUserDiscount();
    this.activatedRoute.paramMap.subscribe(params => {
    this.folder = params.get('id') || 'List of Todas';

    // ✅ Load history ONLY when navigating to "History"
    if (this.folder === 'History') {
      this.loadSearchHistory();
    }
  });
  }
 ngAfterViewInit(): void {
  setTimeout(() => {
    this.loadMap(); // Load the map first
    this.initializeNewNewAutocomplete();
    
    if (!this.searchBox || !this.searchBox.nativeElement) {
      console.error('SearchBox not found in DOM.');
      return;
    }

    if (google && google.maps && google.maps.places) {
      this.initAutocomplete();
    } else {
      console.error('Google Maps API not loaded!');
    }
    
    // Initialize back button handler
    this.initializeBackButtonHandler();
    // Show GPS instructions popup when map loads if needed
    if (!this.hasSeenGpsInstructions && !this.isManualLocationSet) {
      setTimeout(() => {
        this.showGpsInstructions = true;
      }, 1000); // Small delay to ensure map is fully loaded
    }
  }, 1500);  
  // Delay initialization to ensure the DOM is ready
}
  
  clearRoute() {
  if (this.directionsRenderer) {
    this.directionsRenderer.setMap(null);
  }
  this.directionsResponse = null;
  
}
  

  
  selectPlace(place: any) {
    this.recentPlaces.unshift(place.description);
    this.places = []; // Clear dropdown after selection
  }


  openListOfTodas() {
    if (this.folder !== 'List of Todas') {
      this.router.navigate(['/folder', 'List of Todas']);
    }
  }


  ngOnDestroy() {
  this.stopLocationTracking(); // Clean up geolocation watcher
  this.clearRoute();
  
  if (this.map) {
    google.maps.event.clearInstanceListeners(this.map);
    this.map = undefined;
  }
  
  // Clean up back button subscription
  if (this.backButtonSubscription) {
    this.backButtonSubscription.unsubscribe();
  }
}
loadMap() {
  if (!navigator.geolocation) {
    console.error("Geolocation is not supported by this browser.");
    return;
  }

  // Initialize the map
  this.map = new google.maps.Map(document.getElementById('map') as HTMLElement, {
    center: this.center, // Default center (Pasig)
    zoom: 15
  });

  // Add TODA markers
  this.addTodaMarkers();

  // Initialize Directions Service **before** geolocation
  this.directionsService = new google.maps.DirectionsService();
  this.directionsRenderer = new google.maps.DirectionsRenderer({
    map: this.map, // Attach renderer to map
    suppressMarkers: true // Hide default A/B markers (optional)
  });
// Start tracking user location
  this.startLocationTracking();
}

// Add this new method to start/stop tracking:
startLocationTracking() {
   if (!this.hasSeenGpsInstructions && !this.isManualLocationSet) {
    this.showGpsInstructions = true;
    return;
  }
  if (this.watchId !== null) {
    navigator.geolocation.clearWatch(this.watchId);
    this.watchId = null;
  }

  this._isManualLocationSet = false; // Reset manual location flag

  this.watchId = navigator.geolocation.watchPosition(
    (position) => {
      if (!this.map || this.isManualLocationSet) return; // Skip if manual location is set

      const userLocation = {
        lat: position.coords.latitude,
        lng: position.coords.longitude,
      };

      this.currentLocation = userLocation;

      if (!this.userMarker) {
        this.userMarker = new google.maps.Marker({
          position: userLocation,
          map: this.map,
          title: "You are here!",
          icon: {
            url: "https://maps.google.com/mapfiles/ms/icons/blue-dot.png",
            scaledSize: new google.maps.Size(40, 40),
          },
          
        });
      } else {
        this.userMarker.setPosition(userLocation);
      }

      this.map.setCenter(userLocation);
      this.getAddressFromCoordinates(userLocation.lat, userLocation.lng);
    },
    (error) => console.error("Error getting location:", error),
    { enableHighAccuracy: true, maximumAge: 60000, timeout: 60000 }
  );
}

private stopLocationTracking() {
  if (this.watchId !== null) {
    navigator.geolocation.clearWatch(this.watchId);
    this.watchId = null;
  }
  this._isManualLocationSet = true;
}

addTodaMarkers() {
    this.terminalsByToda = {};

    // First grouping pass - using location-based names
    this.todaTerminals.forEach(terminal => {
        const baseName = terminal.name.split('(')[0];
        if (!this.terminalsByToda[baseName]) {
            this.terminalsByToda[baseName] = [];
        }
        this.terminalsByToda[baseName].push(terminal);
    });

    if (!this.map) {
        console.error('Map is not initialized.');
        return;
    }

    // Second grouping pass
    this.terminalsByToda = {};
    this.todaTerminals.forEach(terminal => {
        const baseName = terminal.name.split('(')[0];
        if (!this.terminalsByToda[baseName]) {
            this.terminalsByToda[baseName] = [];
        }
        this.terminalsByToda[baseName].push(terminal);
    });

    // Create markers
    this.todaTerminals.forEach((terminal, index) => {
        const iconUrl = terminalIcons[terminal.name] || '/assets/default-icon.png';

        console.log(`📍 Creating marker: ${terminal.name} at [${terminal.lat}, ${terminal.lng}]`);
        console.log(`Checking icon: ${iconUrl}`);

        // Determine label for markers with multiple locations
        let markerLabel = undefined;
        const marker = new google.maps.Marker({
    position: { lat: terminal.lat, lng: terminal.lng },
    map: this.map,
    title: terminal.name,
    icon: {
        url: iconUrl,
        scaledSize: new google.maps.Size(60, 60),
    },
    zIndex: google.maps.Marker.MAX_ZINDEX + index,
    optimized: false
});

        // Enhanced logging for ST.JOBTODA markers
        if (terminal.name.includes('ST.JOBTODA')) {
            console.log(`✅ ${terminal.name} marker details:`, {
                name: terminal.name,
                position: marker.getPosition()?.toString(),
                visible: marker.getVisible(),
                map: marker.getMap() !== null,
                icon: iconUrl,
                label: markerLabel
            });
        }

        marker.addListener('click', () => {
            console.log(`Marker clicked: ${terminal.name}`);
            
            // Stop the previous marker from bouncing
            if (this.currentBouncingMarker && this.currentBouncingMarker !== marker) {
                this.currentBouncingMarker.setAnimation(null);
            }
            
            // Start this marker bouncing
            marker.setAnimation(google.maps.Animation.BOUNCE);
            
            // Store reference to currently bouncing marker
            this.currentBouncingMarker = marker;
            
            // Set the selected terminal
            if (!this.selectedFromHistory) {
                this.selectedTerminal = terminal;
                this.isBottomBarVisible = true;
                this.showBottomBar(terminal);
            }
            
            // Show routes between terminals of the same TODA
            this.showRoutesBetweenTerminals(terminal.name);
            this.showRouteDisclaimer = true;
        });
    });
    
    console.log(`✅ Total markers created: ${this.todaTerminals.length}`);
}

// Add this method
initializeBackButtonHandler() {
  this.backButtonSubscription = this.platform.backButton.subscribeWithPriority(10, () => {
    // Close open components first
    if (this.isBottomBarVisible) {
      this.closeBottomBar();
      return;
    }
    
    if (this.modal && this.modal.isOpen) {
      this.modal.dismiss();
      return;
    }
    
    if (this.fareModal && this.fareModal.isOpen) {
      this.fareModal.dismiss();
      return;
    }
    
    if (this.isSearchExpanded) {
      this.closeSearchPanel();
      return;
    }
    
    if (this.showPopup) {
      this.closePopup();
      return;
    }
    
    const offset = 8 * 60 * 60 * 1000; // UTC+8 for Philippines
    const currentTime = new Date().getTime() + offset;
    
    if (currentTime - this.lastTimeBackPress < this.timePeriodToExit) {
      // Exit the app
      if (this.platform.is('cordova') || this.platform.is('capacitor')) {
        (navigator as any).app.exitApp();
      }
      // No else clause needed for browser - just ignore exit in browser
    } else {
      this.presentExitToast();
      this.lastTimeBackPress = currentTime;
    }
  });
}



// Add this method to show the exit toast
async presentExitToast() {
  const toast = document.createElement('ion-toast');
  toast.message = 'Press back again to exit';
  toast.duration = 2000;
  toast.position = 'bottom';
  
  document.body.appendChild(toast);
  await toast.present();
}

// Updated method signature to use class property
showRoutesBetweenTerminals(todaName: string) {
  // Clear existing routes first
  this.clearRoutes();
   const baseName = todaName.split('(')[0]; // Get base name before parenthesis
  const terminals = this.terminalsByToda[baseName];
  
  // Only proceed if multiple terminals exist
  if (!terminals || terminals.length <= 1) return;

  // 🚨 SPECIAL CASE: Use custom route for EPSTODA
  if (baseName === 'EPSTODA') {
    this.drawCustomRoute(this.customEpsTodaRoute, '#FF0000');
    return;
  }

   // 🚨 SPECIAL CASE: PSSRMTODA
  if (baseName === 'PSSSRMTODA') {
    this.drawCustomRoute(this.customPsssrmTodaRoute, '#00FF00'); // Green line
    return;
  }

  // Draw red routes between terminals
  terminals.forEach((terminal, index) => {
    if (index < terminals.length - 1) {
      this.drawRoute(
        { lat: terminal.lat, lng: terminal.lng },
        { lat: terminals[index + 1].lat, lng: terminals[index + 1].lng },
        '#FF746C',  // Red color
        index === 0  // Fit bounds for first route only
      );
    }
  });

  // Add this block - shows disclaimer only once per session
  if (!this.hasSeenDisclaimer) {
    this.showRouteDisclaimer = true;
    this.hasSeenDisclaimer = true;
  }
}

closeDisclaimer() {
  this.showRouteDisclaimer = false;
}

private hasSeenDisclaimer: boolean = false;
// NEW METHOD: Draw a single route between two points
drawRoute(origin: {lat: number, lng: number}, destination: {lat: number, lng: number}, color: string, fitBounds: boolean) {
  if (!this.directionsService || !this.map) return;

    if (this.selectedTerminal?.name === 'EPSTODA') {
    this.drawCustomRoute(this.customEpsTodaRoute, color);
    return;
  }

  this.directionsService.route({
    origin: new google.maps.LatLng(origin.lat, origin.lng),
    destination: new google.maps.LatLng(destination.lat, destination.lng),
    travelMode: google.maps.TravelMode.DRIVING
  }, (response, status) => {
    if (status === 'OK' && response) {
      const renderer = new google.maps.DirectionsRenderer({
        suppressMarkers: true,
        preserveViewport: !fitBounds,
        polylineOptions: {
          strokeColor: color,
          strokeOpacity: 0.7,
          strokeWeight: 3  // Thinner line
        }
      });
      renderer.setMap(this.map!);
      renderer.setDirections(response);
      
      // Store renderer for cleanup
      this.activeRouteRenderers.push(renderer);

      if (fitBounds) {
        const bounds = new google.maps.LatLngBounds();
        response.routes[0].legs.forEach(leg => {
          bounds.extend(leg.start_location);
          bounds.extend(leg.end_location);
        });
        this.map?.fitBounds(bounds);
      }
    }
  });
}

private drawCustomRoute(path: google.maps.LatLngLiteral[], color: string = '#FF0000') {
  if (!this.map) return;

  // Clear existing routes first
  this.clearRoutes();

  // Draw the custom path
  const polyline = new google.maps.Polyline({
    path: path,
    geodesic: true,
    strokeColor: color,
    strokeOpacity: 0.7,
    strokeWeight: 3,
    map: this.map
  });

  // Fit bounds to the custom path
  const bounds = new google.maps.LatLngBounds();
  path.forEach(point => bounds.extend(point));
  this.map.fitBounds(bounds);

  // Store for cleanup (optional)
  this.activeRouteRenderers.push({
    setMap: (map: google.maps.Map | null) => polyline.setMap(map)
  } as google.maps.DirectionsRenderer);
}

// NEW METHOD: Clear all existing routes
clearRoutes() {
    this.activeRouteRenderers.forEach(renderer => {
        renderer.setMap(null);
    });
    this.activeRouteRenderers = [];
    
    if (this.destinationMarker) {
        this.destinationMarker.setMap(null);
        this.destinationMarker = null;
    }
    
    // Stop marker bounce when clearing
    if (this.currentBouncingMarker) {
        this.currentBouncingMarker.setAnimation(null);
        this.currentBouncingMarker = null;
    }
}

  // ✅ Reverse Geocoding for User Address
  getAddressFromCoordinates(lat: number, lng: number) {
    this.geocoder.geocode({ location: { lat, lng } }, (results, status) => {
      if (status === "OK" && results?.length) {
        this.currentAddress = results[0].formatted_address;
      } else {
        this.currentAddress = "Location not found";
      }
    });
  }


  // ✅ Open/Close Bottom Bar
  // REPLACE the entire showBottomBar() method (starting around line 1429) with this:

showBottomBar(terminal: any) {
  this.clearSearch(); // Clear everything first
  this.clearRoute();
  const baseName = terminal.name.split('(')[0];
  
  if (baseName === "DEUNITODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Sta. Lucia Mall 48 F Mariano Ave, Pasig, 1610 Metro Manila',
      color: 'White',
      barangay: 'Dela Paz, Pasig City',
      otherTerminals: 'Southville Supermarket Senior Avenue, Chason SouthVille Subd, 1356 2nd St, Eulogio Amang Rodriguez Ave, Pasig, 1610 Metro Manila, 31 Sterly, Pasig, Metro Manila'
    };
  } else if (baseName === "DOCTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER OCTAGON ST. & A. RODRIGUEZ AVE.',
      color: 'Dark Gray',
      barangay: 'Dela Paz, Pasig City',
      otherTerminals: 'ADR, 274 Eulogio Amang Rodriguez Ave, Pasig, 1610 Metro Manila'
    };
  } else if (baseName === "VAMTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Alfonso Ave, Rosario',
      color: 'Light Green',
      barangay: 'Manggahan, Pasig City',
      otherTerminals: '1609 Alfonso, Pasig, 1609 Metro Manila'
    };
  } else if (baseName === "FHNAPICOTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Lifehomes, 3613 E Bank Rd, Pasig, 1609 Metro Manila',
      color: 'Dark Blue',
      barangay: 'Manggahan, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "MPGVTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Greenpark Village Gate 1',
      color: 'Green',
      barangay: 'Manggahan, Pasig City',
      otherTerminals: '103 Hawaii, Pasig, 1800 Metro Manila'
    };
  } else if (baseName === "MAMTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Mabini St. 929 Gomez St, Pasig, Metro Manila',
      color: 'Sky Blue',
      barangay: 'Manggahan, Pasig City',
      otherTerminals: '848 Feliciano Pasco, Pasig, Metro Manila'
    };
  } else if (baseName === "MLKPPTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Lapu-Lapu Magsaysay, 426 Magsaysay, Pasig, 1611 Metro Manila',
      color: 'Maroon',
      barangay: 'Manggahan, Pasig City',
      otherTerminals: 'K Center Building, Imelda Avenue, Kaginhawaan St., Karangalan Village, Pasig, Metro Manila'
    };
  } else if (baseName === "PROFMATODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'In front of Rainforest, 444 Francisco Legaspi, Pasig, Metro Manila',
      color: 'Lightish Dark White',
      barangay: 'Maybunga, Pasig City',
      otherTerminals: 'Pasig Palengke, Westbank Road, Stella Maris, 888 AB Eusebio, Pasig, Metro Manila'
    };
  } else if (baseName === "PRRESJMTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'PCGH Maybunga PI Building, 280 Eusebio, Pasig, 1600 Metro Manila',
      color: 'Grass Green',
      barangay: 'Maybunga, Pasig City',
      otherTerminals: 'Pasig Palengke, Rose Street, Villa, Eusebio, Pasig, Metro Manila'
    };
  } else if (baseName === "PSSSRMTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Taas ng Tulay 470 Francisco Legaspi, Pasig, 1607 Metro Manila',
      color: 'White',
      barangay: 'Maybunga, Pasig City',
      otherTerminals: 'MI SG Bldg Market Ave, Cor Caruncho Ave, Pasig'
    };
  } else if (baseName === "SANSETODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER URBANO VELASCO ST. SAN AGUSTIN ST',
      color: 'Purple',
      barangay: 'Pinagbuhatan, Pasig City',
      otherTerminals: 'Pasig Palengke FG Bldg. Market Ave, corner Caruncho Ave, Pasig, Metro Manila'
    };
  } else if (baseName === "JABSONTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER V. VELASCO ST. & JABSON ST.',
      color: 'Light Blue',
      barangay: 'Pinagbuhatan, Pasig City',
      otherTerminals: 'No other terminals'
    };
  } else if (baseName === "BESCPPTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Corner Esguerra St. & Baltazar St.',
      color: 'Gray',
      barangay: 'Pinagbuhatan, Pasig City',
      otherTerminals: 'No other terminals'
    };
  } else if (baseName === "NAGTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Sunrise Ville or Nagpayong G4Q2+MVH, Orange St, Pasig, Metro Manila',
      color: 'Red',
      barangay: 'Pinagbuhatan, Pasig City',
      otherTerminals: 'Pasig Palengke, Likod ng Novo Gripal Rice Dealer, 3 Caruncho Ave, Pasig, Metro Manila, 102 Eusebio Ave. Dilang 1 Phase 2'
    };
  } else if (baseName === "RAMTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Pasig Palengke Terminal FG Bldg. Market Ave, corner Caruncho Ave, Pasig, Metro Manila',
      color: 'Pink',
      barangay: 'Pinagbuhatan, Pasig City',
      otherTerminals: '25 Block 18 Heroes Street, Pasig, Kalakhang Maynila'
    };
  } else if (baseName === "SPRGEVTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Pasig Central Terminal FG Bldg. Market Ave, corner Caruncho Ave, Pasig, Metro Manila',
      color: 'Yellow',
      barangay: 'Pinagbuhatan, Pasig City',
      otherTerminals: 'No other terminals'
    };
  } else if (baseName === "SLRPPTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Pasig Central Terminal FG Bldg. Market Ave, corner Caruncho Ave, Pasig, Metro Manila',
      color: 'Dark Gray',
      barangay: 'Pinagbuhatan, Pasig City',
      otherTerminals: 'G4V5+66M, Taytay, 1920 Rizal'
    };
  } else if (baseName === "PPCTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Pasig Palengke Terminal FG Bldg. Market Ave, corner Caruncho Ave, Pasig, Metro Manila',
      color: 'Yellow',
      barangay: 'Pinagbuhatan, Pasig City',
      otherTerminals: '34 Urbano Velasco Ave, Pasig, 1602 Metro Manila, 43 Centennial 2A St, Pasig, Metro Manila, Bamboo Ville G3VX+G58, Sta Barbara Centennial 2, Pasig, 1602 Metro Manila'
    };
  } else if (baseName === "MIPTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Pasig Palengke Terminal',
      color: 'Light Gray',
      barangay: 'Pinagbuhatan, Pasig City',
      otherTerminals: 'H422+4C7, Sandoval Ave, Pasig, Metro Manila, Phase 2 Ilugin, Arezzo, CIC205 Sandoval Ave, Pasig, Metro Manila'
    };
  } else if (baseName === "PPEATODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Pasig Palengke Terminal FG Bldg. Market Ave, corner Caruncho Ave, Pasig, Metro Manila',
      color: 'Teal Green',
      barangay: 'Pinagbuhatan, Pasig City',
      otherTerminals: '199 Eusebio Ave, Pasig, 1602 Metro Manila'
    };
  } else if (baseName === "ATODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Pasig Palengke Terminal FG Bldg. Market Ave, corner Caruncho Ave, Pasig, Metro Manila',
      color: 'Yellow',
      barangay: 'Pinagbuhatan, Pasig City',
      otherTerminals: 'Corner San Agustin St., N. Balderama St., Acacia Gahi'
    };
  } else if (baseName === "PPFHTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Pasig Palengke Terminal FG Bldg. Market Ave, corner Caruncho Ave, Pasig, Metro Manila',
      color: 'Dark Indigo',
      barangay: 'Pinagbuhatan, Pasig City',
      otherTerminals: 'FishPort'
    };
  } else if (baseName === "EAPPPTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Pasig Palengke Terminal FG Bldg. Market Ave, corner Caruncho Ave, Pasig, Metro Manila',
      color: 'Blue',
      barangay: 'Pinagbuhatan, Pasig City',
      otherTerminals: 'Super8 Grocery Warehouse Napindan'
    };
  } else if (baseName === "JRFMTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Cor. Rosario Village, Jenny\'s St., Westbank Rd., Maybunga',
      color: 'Teal Green',
      barangay: 'Rosario, Pasig City',
      otherTerminals: '24 Jennys Ave, Pasig, 1609 Metro Manila'
    };
  } else if (baseName === "FEMPATTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Under Ortigas Bridge',
      color: 'Light Blue',
      barangay: 'Rosario, Pasig City',
      otherTerminals: 'No other terminals'
    };
  } else if (baseName === "PRTMGTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Infront of Pasig Greenland Village (497 Jennys Ave, Pasig, 1609 Metro Manila)',
      color: 'Orange Red',
      barangay: 'Rosario, Pasig City',
      otherTerminals: '5 C. Raymundo Ave, Pasig, 1609 Metro Manila, 172 Dr. Sixto Antonio Ave., Pasig, 1609 Metro Manila, 98 Dr. Sixto Antonio Ave., Pasig, 1607 Metro Manila, 3379 C. Raymundo Ave, Pasig, 1609 Metro Manila'
    };
  } else if (baseName === "BRFMTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'H3RW+34P, Ortigas Avenue corner Alfonso Avenue, Pres. Quezon, Pasig, 1609 Metro Manila',
      color: 'Orange',
      barangay: 'Rosario, Pasig City',
      otherTerminals: 'H3RV+CQJ, E Bank Rd, Rosario, Pasig, 1609 Metro Manila'
    };
  } else if (baseName === "TAPCJRTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: '54 Eulogio Amang Rodriguez Ave, Pasig, 1609 Metro Manila',
      color: 'Light Green',
      barangay: 'Rosario, Pasig City',
      otherTerminals: '1 Jabson Pasig, Metro Manila'
    };
  } else if (baseName === "RSGSPSTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'H3QX+W37 Paseo Alfonso, Ortigas Ave, Pasig, 1600 Metro Manila',
      color: 'Light Red',
      barangay: 'Rosario, Pasig City',
      otherTerminals: 'No other terminals'
    };
  } else if (baseName === "RVTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Terminal Riverside Ave. Cor. Ortigas Ave',
      color: 'Sky Blue',
      barangay: 'Santa Lucia, Pasig City',
      otherTerminals: 'No other terminals'
    };
  } else if (baseName === "SMEOTODAPC") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'SM East Ortigas Ave Ext, Brgy, Pasig, 1608 Metro Manila',
      color: 'Sky Blue',
      barangay: 'Santa Lucia, Pasig City',
      otherTerminals: 'No other terminals'
    };
  } else if (baseName === "SLMTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Maybunga Main Mabuhay Subdivision, Main, Pasig, 1608 Metro Manila',
      color: 'Gray',
      barangay: 'Santa Lucia, Pasig City',
      otherTerminals: 'Phase 9, 88 Romeo Thaddeus 10 Pesos Toll, Cainta, Metro Manila'
    };
  } else if (baseName === "PPEMPBRTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Soldiers Village 1222 E Bank Rd, Pasig, 1608 Metro Manila',
      color: 'Dark Gray',
      barangay: 'Santa Lucia, Pasig City',
      otherTerminals: 'Pasig Central Terminal FG Bldg. Market Ave, corner Caruncho Ave, Pasig, Metro Manila'
    };
  } else if (baseName === "SLDECTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'De Castro, Bagong Anyo St.',
      color: 'Medium Gray',
      barangay: 'Santa Lucia, Pasig City',
      otherTerminals: 'De Castro Avenue, Corner Meleguas Street, Pasig, 1608 Metro Manila'
    };
  } else if (baseName === "FERTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Under Ortigas Bridge H3QV+Q96, E Bank Rd, Pasig, 1608 Metro Manila',
      color: 'Black',
      barangay: 'Santa Lucia, Pasig City',
      otherTerminals: 'H476+96V, E Bank Rd, Cainta, 1900 Rizal, H494+PM3, Block 19, Cainta, 1900 Rizal'
    };
  } else if (baseName === "SLEOMTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Super 8 H4Q3+G2Q, Ortigas Ave, Pasig, 1900 Metro Manila',
      color: 'Gold',
      barangay: 'Santa Lucia, Pasig City',
      otherTerminals: 'No other terminals'
    };
  } else if (baseName === "PPMSFLWFMTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Pasig Central Terminal FG Bldg. Market Ave, corner Caruncho Ave, Pasig, Metro Manila',
      color: 'Red',
      barangay: 'Rosario, Pasig City',
      otherTerminals: 'H4F2+57Q, W Bank Rd, Pasig, 1607 Metro Manila'
    };
  } else if (baseName === "EPSTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Crossing, 9 Evangelista St.',
      color: 'Dark Red',
      barangay: 'Santolan, Pasig City',
      otherTerminals: '448, 1610 Evangelista Ave, Pasig, 1800 Metro Manila'
    };
  } else if (baseName === "MERSANTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'Corner Mercedez Ave., & M. Suarez Ave One Mercedes Plaza',
      color: 'Light Blue',
      barangay: 'San Miguel, Pasig City',
      otherTerminals: 'Puregold Mercedes 1387-A Mercedes Ave, Pasig, Metro Manila, Robinsons Mercedes Ave 613 Mercedes Ave, Pasig, 1600 Metro Manila, La Consolacion 641, 1600 Mercedes Ave, Pasig, Metro Manila, Aileen I. Manaog-domingo DMD, 24 Mercedes Ave, San Miguel, Pasig, 1600 Metro Manila'
    };
  }
  
  // ========== NEW TERMINALS FROM PDF ==========
  
  else if (baseName === "BAMATODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER F. MANALO ST. & CARUNCHO AVE.',
      color: 'Light blue',
      barangay: 'Kapitolyo, Pasig City',
      otherTerminals: 'F. ANTONIO INFRONT OF VILLA REGINA'
    };
  } else if (baseName === "BISPPTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER M. FLORES ST. & PASIG BLVD.',
      color: 'Light yellow',
      barangay: 'Kapasigan, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "BITODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER M. FLORES ST. & PASIG BLVD.',
      color: 'Light yellow',
      barangay: 'Kapasigan, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "BIUTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER SAN BUENAVENTURA ST. & SGT. SANTOS ST.',
      color: 'Black',
      barangay: 'Ugong, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "BMPTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER BANAAG ST. PASIG BLVD.',
      color: 'Dark Grey',
      barangay: 'Kapasigan, Pasig City',
      otherTerminals: 'MASILANG ST., STO. NIÑO, STA. MONICA'
    };
  } else if (baseName === "BSJTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CONCEPCION ST. SAN JOAQUIN & SAN GUILLERMO BUTING',
      color: 'Yellow',
      barangay: 'Buting, Pasig City',
      otherTerminals: 'BUTING FLEA MARKET'
    };
  } else if (baseName === "CROSSNATODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CROSSING\'S SUPERMARKET',
      color: 'Green',
      barangay: 'Rosario, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "DODGEVILLETODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'SAGAD ROTONDA C. RAYMUNDO VILLA LAMOK SAGAD',
      color: 'Black',
      barangay: 'Sagad, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "ESCPPTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER E. SANTOS ST. CATLEYA ST.',
      color: 'Blue',
      barangay: 'San Nicolas, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "ISKATODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'ISMAR KALAWAAN, PUROK 6',
      color: 'Red',
      barangay: 'Kalawaan, Pasig City',
      otherTerminals: 'ELISCO ROAD SAN JOAQUIN'
    };
  } else if (baseName === "JASSTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'LOPEZ JAENA, SUMILANG',
      color: 'Red',
      barangay: 'Sumilang, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "JAYNITHSTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'MARKET AVE., F. SORIANO',
      color: 'Blue',
      barangay: 'Kapasigan, Pasig City',
      otherTerminals: 'JAYNITH\'S SUPERMARKET'
    };
  } else if (baseName === "KAPTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'INDUSTRIA ST. BESIDE PLP UNIVERSITY',
      color: 'Green',
      barangay: 'Kapasigan, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "VIAKARTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'PASIG MARKET',
      color: 'Dark green',
      barangay: 'Malinao, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "KATODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER SAN RAFAEL & WEST CAPITOL ST.',
      color: 'Green',
      barangay: 'Capitol Hills, Pasig City',
      otherTerminals: 'SAN IGNACIO ST., WEST CAPITOL INFRONT OF HOLY FAMILY'
    };
  } else if (baseName === "LJSRTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER MACOPA ST. & C. JAENA ST.',
      color: 'Red',
      barangay: 'Sumilang, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "MPMSTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'PASIG MARKET',
      color: 'Dark blue',
      barangay: 'Malinao, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "MRPTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER RED PALM ST. MALINAO & GREEN PALM ST.',
      color: 'Red',
      barangay: 'Malinao, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "OTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'ORANBO DRIVE, INFRONT OF A.B. SANDOVAL BLDG.',
      color: 'White',
      barangay: 'Oranbo, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "GVPPMTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER F. SORIANO ST. PALATIW & MARKET AVE.',
      color: 'Blue',
      barangay: 'Palatiw, Pasig City',
      otherTerminals: 'BUKOHAN PASIG MEGA MARKET'
    };
  } else if (baseName === "PARTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER ALKALDE JOSE ST. & A. MABINI ST.',
      color: 'Green',
      barangay: 'Kapasigan, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "PPRMSSPTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'PASIG CITY MEGA PARKING / AT THE BACK OF JOLIBEE PALENGKE',
      color: 'Blue',
      barangay: 'Malinao, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "PATODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'PASIG CITY MEGA PARKING / AT THE BACK OF JOLIBEE PALENGKE',
      color: 'Blue',
      barangay: 'Malinao, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "PCMSTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'PASIG CITY MEGA PARKING / PASIG MEGA MARKET',
      color: 'Dark Blue',
      barangay: 'Malinao, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "PCMTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'PASIG CITY MEGA PARKING / PASIG MEGA MARKET',
      color: 'Dark Blue',
      barangay: 'Malinao, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "PITODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'A. FLORES ST. BESIDES RHS CANIOGAN',
      color: 'Gray',
      barangay: 'Caniogan, Pasig City',
      otherTerminals: 'PAG ASA ST'
    };
  } else if (baseName === "PLTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'KAPASIGAN BESIDES PASIG LIBRARY',
      color: '',
      barangay: 'Kapasigan, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "PMATODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'PASIG CITY MEGA PARKING / PASIG MEGA MARKET',
      color: 'Blue',
      barangay: 'Malinao, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "PNSTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'SUAREZ VILLE',
      color: 'Green',
      barangay: 'San Nicolas, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "PPMARTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER F. SORIANO ST. PALATIW & MARKET AVE.',
      color: 'White',
      barangay: 'Palatiw, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "PPMTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'PASIG CITY MEGA PARKING / PASIG MEGA MARKET',
      color: 'Blue',
      barangay: 'Malinao, Pasig City',
      otherTerminals: 'LIKOD NG PALENGKE'
    };
  } else if (baseName === "PROTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER DR. MANALO ST. & DR. SIXTO ANTONIO ST.',
      color: 'Light yellow',
      barangay: 'Malinao, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "PRPATODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER C. RAYMUNDO, PAG-ASA ST. CANIOGAN',
      color: 'Blue',
      barangay: 'Caniogan, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "PSBTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER SAN RAFAEL ST. PIONEER ST.',
      color: 'Blue',
      barangay: 'Pioneer, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "RETODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'PASIG CITY MEGA PARKING / PASIG MEGA MARKET',
      color: 'Dark Blue',
      barangay: 'Malinao, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "PMMBTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'PASIG CITY MEGA PARKING / PASIG MEGA MARKET',
      color: 'Dark Blue',
      barangay: 'Malinao, Pasig City',
      otherTerminals: 'PCM'
    };
  } else if (baseName === "S.TODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'F. MANALO ST. BESIDES KAPITOLYO HOMES',
      color: 'Stainless',
      barangay: 'Kapitolyo, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "SAKTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'BESIDES KALAWAAN BRGY. HALL',
      color: 'Dark Green',
      barangay: 'Kalawaan, Pasig City',
      otherTerminals: 'ELISCO RD. SAN JOAQUIN'
    };
  } else if (baseName === "SAMCATODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'ROTONDA BLISS CANIOGAN',
      color: 'Red',
      barangay: 'Caniogan, Pasig City',
      otherTerminals: 'MERCEDEZ EXECUTIVE VILLAGE'
    };
  } else if (baseName === "SANPATODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER M. H. DEL PILAR ST. CARUNCHO AVE.',
      color: 'Purple',
      barangay: 'San Antonio, Pasig City',
      otherTerminals: 'MARKET AVE., COR. DR. PILAPIL'
    };
  } else if (baseName === "SNCPPTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER CARUNCHO COMP. & N. CRUZ ST.',
      color: 'Green',
      barangay: 'San Nicolas, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "SACPTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER M. H. DEL PILAR ST. & M. SUAREZ AVE.',
      color: 'Blue',
      barangay: 'San Antonio, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "SMPSSTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER F. SORIANO ST. PALATIW & MARKET AVE.',
      color: 'Green',
      barangay: 'Palatiw, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "SSMTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER DR. PILAPIL ST. SAGAD & DR. SIXTO ANTONIO AVE., PASIG',
      color: 'Orange',
      barangay: 'Sagad, Pasig City',
      otherTerminals: 'EAST RAYA, MARKET AVE., COR. DR. PILAPIL, LUPANG PARI'
    };
  } else if (baseName === "ST.JOBTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'ULILANG KALAWAAN',
      color: 'Green',
      barangay: 'Kalawaan, Pasig City',
      otherTerminals: 'ELISCO RD. SAN JOAQUIN'
    };
  } else if (baseName === "SMART-LSTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'SUMULONG & ARJAY SUPERMARKET / SMART GROCERY PASIG MEGA MARKET',
      color: 'Dark blue',
      barangay: 'Kapasigan, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "SUMTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER KALAYAAN ST. & E. SANTOS ST.',
      color: 'Dark Blue',
      barangay: 'San Nicolas, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "SVRPMTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'M. SUAREZ AVE.',
      color: 'Blue',
      barangay: 'San Nicolas, Pasig City',
      otherTerminals: 'CORNER F. SORIANO ST. PALATIW'
    };
  } else if (baseName === "UPPTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER LEGASPI ST. & P. ANTONIO ST.',
      color: 'Yellow',
      barangay: 'Ugong, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "VATODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'CORNER SAN AGUSTIN ST. & N. BALDERAMA ST.',
      color: 'Black',
      barangay: 'San Antonio, Pasig City',
      otherTerminals: ''
    };
  } else if (baseName === "VRTODA") {
    this.selectedTerminal = {
      name: terminal.name,
      location: 'J. B. MIGUEL ST.',
      color: 'White',
      barangay: 'San Miguel, Pasig City',
      otherTerminals: ''
    };
  } else {
    this.selectedTerminal = {
      name: terminal.name,
      location: terminal.location || 'No location available',
      color: terminal.color || 'Not specified',
      barangay: terminal.barangay || 'Not specified',
      otherTerminals: terminal.otherTerminals || 'None'
    };
  }
  
  this.isBottomBarVisible = true;
}

  closeBottomBar() {
    this.isBottomBarVisible = false;
    
        if (this.currentBouncingMarker) {
        this.currentBouncingMarker.setAnimation(null);
        this.currentBouncingMarker = null;
        }
  }

  // ✅ Open/Close Compute Fare Modal
  openFareModal() {
    this.fareModal.present();
    cssClass: 'fare-modal'
    this.calculateFare(); // Recalculate before showing
  this.modal.present(); // Manually present modal
  }

  closeFareModal() {
    this.fareModal.dismiss();
  }

  computeFare() {
    console.log(`Opening fare computation for ${this.selectedTerminal?.name}`);
    this.openFareModal();
    
  }

  // ✅ Search Panel Functions
  toggleSearchPanel() {
    this.isSearchExpanded = !this.isSearchExpanded;
  }

  switchTab(tab: string) {
    this.activeTab = tab;
  }

  closeSearchPanel() {
    this.isSearchExpanded = false;
  }

clearSearch() {
  this.newSearchQuery = '';
  this.searchQuery = '';
  this.selectedPlace = null;
  this.selectedPlaceName = '';
  this.places = [];
  this.searchedLocation = { lat: 0, lng: 0 };

  if (this.searchBox?.nativeElement) {
    this.searchBox.nativeElement.value = '';
  }
  if (this.newSearchBoxRef?.nativeElement) {
    this.newSearchBoxRef.nativeElement.value = '';
  }

  if (this.destinationMarker) {
    this.destinationMarker.setMap(null);
    this.destinationMarker = null;
  }

  this.isNewSearchExpanded = false;
  this.isSearchExpanded = false;

  this.cdRef.detectChanges();
}
recentSearches: any[] = [];
openSearchPanel(type: 'start' | 'destination') {
  
  this.dismissModal(); 
  this.isSearchExpanded = true;

  this.loadSearchHistory();

  setTimeout(() => {
    const searchInput = document.querySelector(
      'input[placeholder="Search for places..."]'
    ) as HTMLInputElement;
    if (searchInput) {
      searchInput.focus();
    }
  }, 300);
}

loadSearchHistory() {
  const identifier = this.getUserIdentifier();

  this.recentSearches = [];
  this.fullSearchHistory = [];

  if (!identifier) {
    console.warn('🚫 No user identifier found. Clearing search history.');
    return;
  }

  this.http.post<any>('https://qid.duv.temporary.site/history-api/getHistory.php', {
    user_email: identifier // ✅ still named user_email for backend compatibility
  }).subscribe(
    (res) => {
      if (res.status === 'success' && Array.isArray(res.history)) {
        const normalized = res.history.map((item: any) => ({
          ...item,
          from: item.from ?? item.origin ?? 'Unknown Origin',
          to: item.to ?? item.destination ?? 'Unknown Destination'
        }));

        this.recentSearches = normalized.slice(0, 5);
        this.fullSearchHistory = normalized;
      } else {
        console.warn('⚠️ No history or bad response. Clearing state.');
        this.recentSearches = [];
        this.fullSearchHistory = [];
      }
    },
    (err) => {
      console.error('❌ Server error while fetching history:', err);
      this.recentSearches = [];
      this.fullSearchHistory = [];
    }
  );
}


saveSearchHistory() {
  const identifier = this.getUserIdentifier();

  if (!identifier) {
    console.warn('No user identifier found, cannot save search history.');
    return;
  }

  const data = {
    user_email: identifier,                 // ✅ email OR phone
    terminal: this.selectedTerminal?.name || '',
    from: this.selectedTerminal?.name || '', // terminal name
    to: this.selectedPlaceName,
    km: this.km,
    baseRate: this.baseRate,
    additionalRate: this.additionalRate,
    discount: this.discount,
    totalFare: this.fare
  };

  this.http.post<any>('https://qid.duv.temporary.site/history-api/saveHistory.php', data).subscribe(
    (res) => {
      if (res.status === 'success') {
        console.log('Search history saved.');
      } else {
        console.error('Failed to save history:', res.message);
      }
    },
    (err) => {
      console.error('Error saving search history:', err);
    }
  );
}
async onSelectHistory(item: any) {
  this.selectedFromHistory = true;
  
  // Handle both old and new format records
  const terminalName = item.terminal || item.from;
   const baseName = terminalName.split('(')[0]; // Get base name before parenthesis
  
  // Find first terminal with matching base name
  this.selectedTerminal = this.todaTerminals.find(t => 
    t.name.split('(')[0] === baseName
  );

  if (!this.selectedTerminal) {
    console.warn('TODA not found for:', terminalName);
    return;
  }

  try {
    // Get coordinates for destination
    this.searchedLocation = await this.getCoordinatesFromAddress(item.to || item.destination);
    this.selectedPlaceName = item.to || item.destination;

    // Find terminal coordinates
    const terminal = this.todaTerminals.find(t => t.name === this.selectedTerminal.name);
    if (terminal) {
      // Calculate distance from terminal to destination
      this.km = await this.computeRoadDistance(
        { lat: terminal.lat, lng: terminal.lng },
        this.searchedLocation
      );
      this.km = Math.ceil(this.km);
      
      console.log('Calculated distance:', this.km, 'km');
    }

    // Apply fare details from history
    this.baseRate = item.base_rate || this.baseRate;
    this.additionalRate = item.additional_rate || 0;
    this.discount = item.discount || 0;
    this.fare = item.total_fare || 0;

    // Draw the route
    await this.storeRouteForDisplay();

    // Show fare breakdown
    this.showPopup = false;
    this.cdRef.detectChanges();
    setTimeout(() => this.showPopup = true, 50);

  } catch (error) {
    console.error('Error selecting history item:', error);
    this.showToast('Failed to load location from history', 'danger');
  }
}



computeFinalFare() {
  if (!this.destination) {
    alert("Please select a destination first.");
    return;
  }

  console.log(`Computing fare from ${this.startingLocation} to ${this.destination}`);

  // Make sure fare is calculated before saving history
  this.calculateFare();

  this.saveSearchHistory();
}

cancel() {
  this.modal.dismiss(null, 'cancel');
}

confirm() {
  this.modal.dismiss(null, 'confirm');
}

closeModal() {
  this.modal.dismiss();
}

onWillDismiss(event: CustomEvent<OverlayEventDetail>) {
  if (event.detail.role === 'confirm') {
    console.log('Modal Confirmed:', event.detail.data);
  }
}

goBack() {
  this.navCtrl?.back() ?? this.router.navigate(['/previous-page']);
}

selectedButton: number | null = null;
buttons = [
  'Overall Service',
  'Features',
  'Updated Terminal Locations',
  'Problems Encountered'
];


discountRate: number = 0;
selectedDiscount: string = '';
email: string = '';

loadUserDiscount(): void {
  const identifier = this.getUserIdentifier();
  if (!identifier) {
    this.showToast('Please login first', 'warning');
    return;
  }

  this.email = identifier;

  this.http.post<any>('https://qid.duv.temporary.site/profile-api/getProfile.php', {
    email: identifier // ✅ email OR phone
  }).subscribe({
    next: (res) => {
      console.log('📦 Full profile response:', res);

      this.selectedDiscount = res.discount || '';
      console.log('🎯 Discount string:', this.selectedDiscount);

      const total = this.baseRate + this.additionalRate;
      this.discountRate = this.convertDiscountToAmount(this.selectedDiscount, total);

      this.calculateFare();
    },
    error: () => {
      this.showToast('Failed to load discount info', 'danger');
    }
  });
}


convertDiscountToAmount(discountStr: string, totalFare: number): number {
  if (!discountStr) return 0;

  const lower = discountStr.toLowerCase();

  if (lower.includes('student') || lower.includes('pwd') || lower.includes('senior')) {
    return totalFare * 0.20; // 20% discount
  }

 const parsed = parseFloat(discountStr);
if (!isNaN(parsed)) {
  if (discountStr.trim().endsWith('%')) {
    const percentDiscount = totalFare * (parsed / 100);
    return parseFloat(percentDiscount.toFixed(2));
  }
  return parseFloat(parsed.toFixed(2)); // Fixed amount discount
}


  return 0;
}

calculateFare(): void {
  const km = this.km;
  const baseKm = this.baseKm;

  // ➤ Calculate additional rate
  if (km <= baseKm) {
    this.additionalRate = 0;
  } else {
    const extraKm = km - baseKm;
    const wholeKm = Math.floor(extraKm);
    const partialKm = extraKm - wholeKm;

    const wholeFare = wholeKm * this.perKm;
    const partialFare = partialKm > 0 ? this.perKm : 0;

    this.additionalRate = wholeFare + partialFare;
  }

  const totalBeforeDiscount = this.baseRate + this.additionalRate;

  // ➤ Determine discount
  if (this.selectedDiscount) {
    const lower = this.selectedDiscount.toLowerCase();

    if (lower.includes('student') || lower.includes('pwd') || lower.includes('senior')) {
      // Fixed 20% on base rate only
      this.discount = this.baseRate * 0.20;
    } else if (lower.includes('%')) {
      // Percentage discount on total
      const percent = parseFloat(lower);
      this.discount = isNaN(percent) ? 0 : totalBeforeDiscount * (percent / 100);
    } else {
      // Fixed amount discount
      const fixed = parseFloat(this.selectedDiscount);
      this.discount = isNaN(fixed) ? 0 : fixed;
    }
  } else {
    this.discount = 0;
  }

  // ➤ Prevent over-discounting
  if (this.discount > totalBeforeDiscount) {
    this.discount = totalBeforeDiscount;
  }

  // ➤ Final fare
  this.fare = Math.max(0, totalBeforeDiscount - this.discount);
  this.fare = Math.round(this.fare * 100) / 100;
}
getDiscountDescription(discount: string): string {
  if (!discount) return 'None';

  const lower = discount.toLowerCase();

  if (lower.includes('student')) return 'Student (20%)';
  if (lower.includes('pwd')) return 'PWD (20%)';
  if (lower.includes('senior')) return 'Senior Citizen (20%)';
  if (lower.includes('%')) return `${discount} off`;
  if (!isNaN(Number(discount))) return `₱${Number(discount).toFixed(2)} off`;

  return 'Custom Discount';
}
async logout() {
  const alert = await this.alertController.create({
    header: 'Confirm Logout',
    message: 'Are you sure you want to log out?',
    buttons: [
      {
        text: 'Cancel',
        role: 'cancel'
      },
      {
        text: 'Logout',
        handler: () => {
          // Clear user data from storage
          localStorage.removeItem('userEmail');
           localStorage.removeItem('user_email');
          localStorage.removeItem('userPassword');
          localStorage.removeItem('userData'); // if exists
          localStorage.removeItem('userProfileImageUrl'); // <-- Add this line
          localStorage.clear();
          // Dispatch unified event for auth change
          window.dispatchEvent(new Event('userAuthChanged'));

          // Navigate to login page
          this.router.navigate(['/login']);

          // Optional: Show confirmation toast
          this.showToast('You have been logged out', 'success');
        }
      }
    ]
  });

  await alert.present();
}


getUniqueDiscountDescriptions(): string[] {
  if (!this.selectedDiscount) return [];

  // Split by commas if multiple discounts are stored like "pwd,pwd,student"
  const discounts = this.selectedDiscount
    .toLowerCase()
    .split(',')
    .map(d => d.trim())
    .filter(d => d.length > 0);

  // Remove duplicates
  const uniqueDiscounts = Array.from(new Set(discounts));

  // Map to description strings
  return uniqueDiscounts.map(d => this.getDiscountDescription(d));
}
formatNumber(value: number): number {
  if (value === null || value === undefined) return 0;
  return parseFloat(value.toFixed(2));
}
async confirmDeleteAccount() {
  const alert = await this.alertController.create({
    header: 'Confirm Delete',
    subHeader: 'Are you sure?',
    message: 'This action will permanently delete your account. This cannot be undone.',
    buttons: [
      {
        text: 'Cancel',
        role: 'cancel'
      },
      {
        text: 'Delete',
        role: 'destructive',
        handler: () => {
          // ✅ identifier can be EMAIL OR PHONE (supports legacy key too)
          const identifier =
            localStorage.getItem('userEmail') ||
            localStorage.getItem('user_email');

          const isGoogleUser = localStorage.getItem('isGoogleUser') === 'true';

          if (!identifier) {
            this.showToast('No account identifier found. Please login again.', 'warning');
            this.router.navigate(['/login']);
            return;
          }

          if (isGoogleUser) {
            // If user logged in via Google, skip delete API and just redirect
            this.clearLocalUserData();
            this.router.navigate(['/signup']);
            this.showToast('Google user logged out', 'success');
            return;
          }

          // Normal delete flow for non-Google users
          this.deleteAccountFromServer(identifier);
          this.clearLocalUserData();
          this.router.navigate(['/signup']);
          this.showToast('Account deleted successfully', 'success');
        }
      }
    ]
  });

  await alert.present();
}

private clearLocalUserData() {
  // Remove user identifiers
  localStorage.removeItem('userEmail');   // email OR phone identifier
  localStorage.removeItem('user_email');  // legacy key support

  // Remove stored credentials
  localStorage.removeItem('userPassword');
  localStorage.removeItem('userData');

  // Remove profile-related data
  localStorage.removeItem('userProfileImageUrl');
  localStorage.removeItem('authCodeSaved');

  // Remove Google login flag
  localStorage.removeItem('isGoogleUser');

  // Notify app components that auth state changed
  window.dispatchEvent(new Event('userAuthChanged'));
}

deleteAccountFromServer(email: string | null) {
  if (!email) return;

  this.http.post<any>('https://qid.duv.temporary.site/account-api/delete-account.php', { email })
    .subscribe({
      next: (res) => {
        if (!res.success) {
          this.showToast(res.message || 'Failed to delete account on server', 'danger');
        }
      },
      error: (err) => {
        console.error('Delete account server error:', err);
      }
    });
}
selectButton(index: number) {
  this.selectedButton = index;
}

// Called when user submits feedback
submitFeedback() {
  if (this.selectedButton === null) {
    this.showToast('Please select a feedback category.', 'warning');
    return;
  }

  if (!this.feedbackMessage.trim()) {
    this.showToast('Please enter your feedback.', 'warning');
    return;
  }

  // Compose payload
  const payload = {
    category: this.buttons[this.selectedButton],
    message: this.feedbackMessage.trim(),
    user_email: this.getUserIdentifier() || 'anonymous'
  };

  this.http.post('https://qid.duv.temporary.site/submitFeedback.php', payload).subscribe({
    next: (res: any) => {
      if (res.status === 'success') {
        this.showToast('Thank you for your feedback!', 'success');
        this.resetFeedback();
      } else {
        this.showToast(res.message || 'Failed to submit feedback.', 'danger');
      }
    },
    error: () => {
      this.showToast('Error submitting feedback.', 'danger');
    }
  });
}

resetFeedback() {
  this.selectedButton = null;
  this.feedbackMessage = '';
}

async showToast(message: string, color: string = 'success') {
  const toast = await this.toastCtrl.create({
    message,
    duration: 2000,
    color,
    position: 'bottom'
  });
  await toast.present();
}
}