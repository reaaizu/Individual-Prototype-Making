import { initializeApp } from 'firebase/app';

const firebaseConfig = {
  apiKey: "AIzaSyC8ShElKOLoVt8mNm8BtGd1jUl6qHdjxWU",
  authDomain: "tricy-track-ebc7c.firebaseapp.com",
  projectId: "tricy-track-ebc7c",
  storageBucket: "tricy-track-ebc7c.appspot.com",
  messagingSenderId: "32815437782",
  appId: "1:32815437782:web:5f63f7500bbd36108fb677",
  measurementId: "G-BRGSL08T7S"
};



export const firebaseApp = initializeApp(firebaseConfig);