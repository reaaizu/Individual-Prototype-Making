import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import {
  IonicModule,
  NavController,
  ToastController,
  AlertController,
  ModalController,
} from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { ChangeDetectorRef } from '@angular/core';
import { ImageCroppedEvent, ImageCropperComponent } from 'ngx-image-cropper';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
  standalone: true,
  imports: [ImageCropperComponent, FormsModule, CommonModule, IonicModule],
})
export class ProfilePage implements OnInit {
  // ----------------------------
  // UI fields
  // ----------------------------
  identifier = ''; // what the user used to login (email OR phone)
  identifierLabel = 'Email';

  email = ''; // optional: if your backend still returns an email column
  phone: string | null = null;

  password = '******';
  isPasswordVisible = false;

  selectedDiscount = ''; // '', 'student', 'pwd', 'senior'

  // authCode === null means "no auth code in DB yet"
  // authCode === '******' means "exists in DB"
  authCode: string | null = null;

  // profile picture
  profileImageUrlWithTimestamp: string | null = null;
  profileImageUrl: string | null = null;

  // image crop state
  selectedFile: File | null = null;
  imageChangedEvent: any = null;
  croppedImage: string | null = null;
  showCropper = false;

  @ViewChild('fileInput') fileInput!: ElementRef<HTMLInputElement>;

  private readonly API_BASE = 'https://qid.duv.temporary.site';

  constructor(
    private navCtrl: NavController,
    private http: HttpClient,
    private toastCtrl: ToastController,
    private alertCtrl: AlertController,
    private cdr: ChangeDetectorRef,
    private modalCtrl: ModalController
  ) {}

  ngOnInit(): void {
    // ✅ DB is the source of truth. DO NOT use localStorage to decide auth code existence.
    this.loadProfile();
  }

  // ----------------------------
  // Helpers: email/phone display
  // ----------------------------
  private normalizePhone(value: string): string {
    return value.replace(/[^\d+]/g, '');
  }

  private isPhone(value: string): boolean {
    const phone = this.normalizePhone(value);
    return /^\+?\d{10,15}$/.test(phone);
  }

  private setIdentifierDisplay(loggedInIdentifier: string, res?: any): void {
    const asPhone = this.isPhone(loggedInIdentifier);
    this.identifierLabel = asPhone ? 'Phone' : 'Email';

    // Prefer the identifier used to login, but if you want you can prefer DB value when present:
    // this.identifier = asPhone ? (res?.phone || loggedInIdentifier) : (res?.email || loggedInIdentifier);

    this.identifier = loggedInIdentifier;
  }

  // ----------------------------
  // Load Profile
  // ----------------------------
  loadProfile(): void {
    const loggedInIdentifier = localStorage.getItem('userEmail'); // can be email OR phone
    if (!loggedInIdentifier) {
      this.showToast('Please login first', 'warning');
      this.navCtrl.navigateBack('/login');
      return;
    }

    this.http
      .post<any>(`${this.API_BASE}/profile-api/getProfile.php`, {
        email: loggedInIdentifier, // backend expects key "email" but it's actually identifier
      })
      .subscribe({
        next: (res) => {
          // display identifier (email/phone)
          this.setIdentifierDisplay(loggedInIdentifier, res);

          // optional extra values
          this.email = res.email || '';
          this.phone = res.phone ?? null;

          this.selectedDiscount = res.discount || '';

          // ✅ backend returns: authCode = "exists" or null
          this.authCode = res.authCode ? '******' : null;

          // Update locally
          this.updateProfileImage(res.profile_picture);

          // ✅ Sync with sidebar image
          if (res.profile_picture) {
            const cleanedUrl = String(res.profile_picture).replace(/[?&]t=\d+/, '');
            const separator = cleanedUrl.includes('?') ? '&' : '?';
            const timestampedUrl = `${cleanedUrl}${separator}t=${Date.now()}`;

            localStorage.setItem('userProfileImageUrl', timestampedUrl);
            window.dispatchEvent(new Event('userProfileUpdated'));
          } else {
            localStorage.removeItem('userProfileImageUrl');
            window.dispatchEvent(new Event('userProfileUpdated'));
          }
        },
        error: (err) => {
          console.error('Profile load error:', err);
          this.showToast('Failed to load profile', 'danger');
        },
      });
  }

  updateProfileImage(url: string | null): void {
    if (!url) {
      this.profileImageUrl = null;
      this.profileImageUrlWithTimestamp = null;
      return;
    }

    const cleanedUrl = String(url).replace(/[?&]t=\d+/, '');
    const separator = cleanedUrl.includes('?') ? '&' : '?';
    const timestamp = Date.now();

    this.profileImageUrl = cleanedUrl;
    this.profileImageUrlWithTimestamp = `${cleanedUrl}${separator}t=${timestamp}`;
    setTimeout(() => this.cdr.detectChanges());
  }

  // ----------------------------
  // Profile image picking (triggered by clicking the circle)
  // ----------------------------
  public openFilePicker(): void {
    // opens hidden file input
    if (this.fileInput?.nativeElement) {
      this.fileInput.nativeElement.click();
    }
  }

  onFileSelected(event: any): void {
    const file = event?.target?.files?.[0] as File | undefined;
    if (!file) return;

    if (!this.isValidImage(file)) {
      this.showToast('Invalid image type (JPEG/PNG only)', 'warning');
      this.resetFileInput();
      return;
    }

    this.selectedFile = file;
    this.imageChangedEvent = event;

    // show fullscreen-ish modal cropper UI (controlled by template)
    this.openCropperModal();
  }

  isValidImage(file: File): boolean {
    return ['image/jpeg', 'image/png'].includes(file.type);
  }

  imageCropped(event: ImageCroppedEvent): void {
    this.croppedImage = event.base64 ?? '';
  }

  // ----------------------------
  // Cropper modal controls
  // (Template will show <ion-modal> when showCropperModal is true)
  // ----------------------------
  openCropperModal(): void {
    this.showCropper = true;
    setTimeout(() => this.cdr.detectChanges());
  }

  closeCropperModal(): void {
    this.showCropper = false;
    setTimeout(() => this.cdr.detectChanges());
  }

  cropCanceled(): void {
    this.resetImageState();
    this.closeCropperModal();
  }

  // ----------------------------
  // Upload cropped image
  // ----------------------------
  uploadImage(): void {
    if (!this.croppedImage && !this.selectedFile) {
      this.showToast('No image selected', 'warning');
      return;
    }

    const loggedInIdentifier = localStorage.getItem('userEmail');
    if (!loggedInIdentifier) {
      this.showToast('Session expired', 'warning');
      return;
    }

    const formData = new FormData();
    const imageToUpload = this.croppedImage
      ? this.base64ToFile(this.croppedImage)
      : this.selectedFile!;

    formData.append('image', imageToUpload, 'profile.jpg');

    // backend expects "email" but it is really identifier (email OR phone)
    formData.append('email', loggedInIdentifier);

    this.http
      .post<any>(`${this.API_BASE}/profile-api/upload-image.php`, formData)
      .subscribe({
        next: (res) => {
          if (res.success) {
            this.updateProfileImage(res.imageUrl);

            const cleanedUrl = String(res.imageUrl).replace(/[?&]t=\d+/, '');
            const separator = cleanedUrl.includes('?') ? '&' : '?';
            const finalUrl = `${cleanedUrl}${separator}t=${Date.now()}`;
            localStorage.setItem('userProfileImageUrl', finalUrl);

            // update menu immediately
            window.dispatchEvent(new Event('userAuthChanged'));

            this.resetImageState();
            this.closeCropperModal();
            this.showToast('Profile picture updated!', 'success');
          } else {
            this.showToast(res.message || 'Upload failed', 'danger');
          }
        },
        error: (err) => {
          console.error('Upload error:', err);
          this.showToast('Upload failed', 'danger');
        },
      });
  }

  private base64ToFile(base64: string): File {
    const arr = base64.split(',');
    const mime = arr[0].match(/:(.*?);/)?.[1] ?? 'image/jpeg';
    const bstr = atob(arr[1]);
    const u8arr = new Uint8Array(bstr.length);
    for (let i = 0; i < bstr.length; i++) u8arr[i] = bstr.charCodeAt(i);
    return new File([u8arr], 'profile.jpg', { type: mime });
  }

  private resetImageState(): void {
    this.croppedImage = '';
    this.imageChangedEvent = null;
    this.selectedFile = null;
    this.resetFileInput();
  }

  private resetFileInput(): void {
    if (this.fileInput?.nativeElement) {
      this.fileInput.nativeElement.value = '';
    }
  }

  // ----------------------------
  // Auth Code + Password viewing
  // Desired behavior:
  // - if no auth code in DB -> user must create one
  // - if auth code exists -> ask to enter and verify
  // ----------------------------
  public async viewPassword(): Promise<void> {
    // authCode null means not set in DB
    if (!this.authCode) {
      await this.promptForNewAuthCode();
      return;
    }

    await this.verifyAuthCodeForPassword();
  }

  private async promptForNewAuthCode(): Promise<void> {
    const alert = await this.alertCtrl.create({
      header: 'Setup Authentication',
      message: 'Create an authentication code to view your password',
      inputs: [{ name: 'newCode', type: 'password', placeholder: 'New authentication code' }],
      buttons: [
        { text: 'Cancel', role: 'cancel' },
        {
          text: 'Save',
          handler: (data) => {
            const code = String(data?.newCode ?? '').trim();
            if (code) this.saveAuthCode(code);
            return true;
          },
        },
      ],
    });
    await alert.present();
  }

  private async verifyAuthCodeForPassword(): Promise<void> {
    const alert = await this.alertCtrl.create({
      header: 'Authentication Required',
      message: 'Enter your authentication code',
      inputs: [{ name: 'enteredCode', type: 'password', placeholder: 'Authentication code' }],
      buttons: [
        { text: 'Cancel', role: 'cancel' },
        {
          text: 'Verify',
          handler: (data) => {
            const code = String(data?.enteredCode ?? '').trim();
            if (!code) {
              this.showToast('Please enter your authentication code', 'warning');
              return false;
            }
            this.verifyAuthcode(code);
            return true;
          },
        },
      ],
    });
    await alert.present();
  }

  private verifyAuthcode(code: string): void {
    const loggedInIdentifier = localStorage.getItem('userEmail');
    if (!loggedInIdentifier) return;

    this.http
      .post<any>(`${this.API_BASE}/profile-api/verifyAuthCode.php`, {
        email: loggedInIdentifier, // identifier
        authCode: code,
      })
      .subscribe({
        next: (res) => {
          if (res.success) {
            this.password = res.password;
            this.isPasswordVisible = true;
            this.showToast('Authentication successful', 'success');
          } else {
            this.showToast('Invalid code', 'danger');
          }
        },
        error: () => this.showToast('Verification failed', 'danger'),
      });
  }

  private saveAuthCode(code: string): void {
    const loggedInIdentifier = localStorage.getItem('userEmail');
    if (!loggedInIdentifier) return;

    this.http
      .post<any>(`${this.API_BASE}/profile-api/saveAuthCode.php`, {
        email: loggedInIdentifier, // identifier
        authCode: code,
      })
      .subscribe({
        next: (res) => {
          if (res.success) {
            this.authCode = '******'; // now exists in DB
            this.showToast('Code saved successfully', 'success');
          } else {
            this.showToast('Failed to save code', 'danger');
          }
        },
        error: () => this.showToast('Error saving code', 'danger'),
      });
  }

  // ----------------------------
  // Discount saving
  // ----------------------------
  saveDiscount(): void {
    const loggedInIdentifier = localStorage.getItem('userEmail');
    if (!loggedInIdentifier) {
      this.showToast('Session expired', 'warning');
      return;
    }

    // you use '' as "None"
    const discountToSend = this.selectedDiscount === '' ? null : this.selectedDiscount;

    this.http
      .post<any>(`${this.API_BASE}/profile-api/saveDiscount.php`, {
        email: loggedInIdentifier, // identifier
        discount: discountToSend,
      })
      .subscribe({
        next: () => this.showToast('Discount saved', 'success'),
        error: () => this.showToast('Failed to save discount', 'danger'),
      });
  }

  // ----------------------------
  // Reset password flow
  // Must require existing auth code in DB
  // ----------------------------
  public async resetPassword(): Promise<void> {
    if (!this.authCode) {
      this.showToast('Please set your authentication code first.', 'warning');
      await this.promptForNewAuthCode();
      return;
    }

    await this.initiatePasswordReset();
  }

  private async initiatePasswordReset(): Promise<void> {
    const loggedInIdentifier = localStorage.getItem('userEmail');
    if (!loggedInIdentifier) {
      this.showToast('Session expired', 'warning');
      return;
    }

    const alert = await this.alertCtrl.create({
      header: 'Reset Password',
      message: 'Enter authentication code and new password',
      inputs: [
        { name: 'authCode', type: 'password', placeholder: 'Authentication code' },
        { name: 'newPassword', type: 'password', placeholder: 'New password' },
      ],
      buttons: [
        { text: 'Cancel', role: 'cancel' },
        {
          text: 'Reset',
          handler: (data) => {
            const authCode = String(data?.authCode ?? '').trim();
            const newPassword = String(data?.newPassword ?? '').trim();

            if (!authCode || !newPassword) {
              this.showToast('All fields required', 'warning');
              return false;
            }

            this.resetPasswordConfirmed(authCode, newPassword);
            return true;
          },
        },
      ],
    });

    await alert.present();
  }

  private resetPasswordConfirmed(authCode: string, newPassword: string): void {
    const loggedInIdentifier = localStorage.getItem('userEmail');
    if (!loggedInIdentifier) return;

    // verify auth code first
    this.http
      .post<any>(`${this.API_BASE}/profile-api/verifyAuthCode.php`, {
        email: loggedInIdentifier, // identifier
        authCode,
      })
      .subscribe({
        next: (verifyRes) => {
          if (!verifyRes.success) {
            this.showToast('Invalid authentication code', 'danger');
            return;
          }

          // then reset password
          this.http
            .post<any>(`${this.API_BASE}/profile-api/resetPassword.php`, {
              email: loggedInIdentifier, // identifier
              newPassword,
            })
            .subscribe({
              next: (resetRes) => {
                if (resetRes.status === 'success') {
                  this.password = '******';
                  this.isPasswordVisible = false;
                  this.showToast('Password reset successful', 'success');
                } else {
                  this.showToast(resetRes.message || 'Reset failed', 'danger');
                }
              },
              error: () => this.showToast('Reset failed', 'danger'),
            });
        },
        error: () => this.showToast('Verification failed', 'danger'),
      });
  }

  // ----------------------------
  // Navigation + toast
  // ----------------------------
  goBack(): void {
    this.navCtrl.back();
  }

  async showToast(message: string, color: string = 'success'): Promise<void> {
    const toast = await this.toastCtrl.create({
      message,
      duration: 2000,
      position: 'bottom',
      color,
    });
    await toast.present();
  }

  getTimestamp(): number {
    return Date.now();
  }
}