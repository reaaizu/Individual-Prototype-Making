import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular'; // ✅ Import IonicModule

@Component({
  selector: 'app-how',
  templateUrl: './how.page.html',
  styleUrls: ['./how.page.scss'],
  standalone: true, // ✅ Ensure it's standalone
  imports: [IonicModule] // ✅ Add IonicModule here
})
export class HowPage {}
