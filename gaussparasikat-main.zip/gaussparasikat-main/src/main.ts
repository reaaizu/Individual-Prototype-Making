import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/app.module';
import { SplashScreen } from '@capacitor/splash-screen';

platformBrowserDynamic().bootstrapModule(AppModule)
  .then(() => {
    // Hide the Capacitor Splash Screen when Angular is fully loaded
    SplashScreen.hide();

    // Remove the custom GIF splash and show the main app
    document.getElementById('custom-splash')?.remove();
    document.querySelector('app-root')?.setAttribute('style', 'display: block;');
  })
  .catch(err => console.log(err));
