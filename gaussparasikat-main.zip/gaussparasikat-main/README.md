WAG PO GAMITIN YUNG CODES NA CINOMMIT NI MAYUMIMYKAELA HAHHEHEAHEAHEHEAHA
Andrea was here <3
nagtatae po si andrea
tulog po si andrea
ang angas k talaga