import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'io.ionic.starter',
  appName: 'Tricy-Track',
  webDir: 'www',
  plugins: {
    SplashScreen: {
      launchShowDuration: 0,    
      launchAutoHide: true,     
      androidScaleType: 'CENTER_CROP',
      splashFullScreen: true,
      splashImmersive: true
    },
    GoogleMaps: {
      apiKey: "AIzaSyCvZBUCdQG6DCUBVoTOwBJDf2vMLPAYeT4"
    }
  },
  server: {
    cleartext: true,
    androidScheme: 'https', 
    allowNavigation: ["*"], 
  }
};

export default config;
